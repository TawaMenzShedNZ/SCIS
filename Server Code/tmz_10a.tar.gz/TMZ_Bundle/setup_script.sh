#!/bin/bash

# Setup env variables
if [[ ! -f /tmp/scratch_var ]]
then
	touch /tmp/scratch_var
fi

if [[ ! -f /usr/local/etc/scis_defaults ]]
then
	echo "ORGANISATION:" > /usr/local/etc/scis_defaults
fi
export SCRIPT=$(realpath "$0")
echo "Dollar 0 $0"
export WDIR=$(dirname "${SCRIPT}")

# Promot for PIN
echo "Enter 4 digit security PIN:"
read PIN
if [[ "${PIN}" == "" ]]
then
	echo "Pin is mandatory -exiting"
	exit
fi
export WCL=`echo "${PIN}" |awk '{print length($1)}'`
if (( $WCL != 4 ))
then
	echo "PIN must be 4 digits long - exiting"
	exit
fi

export WCL=`echo "${PIN}" |sed 's/[0-9]//g' |awk '{print NF}'`
if (( $WCL > 0 ))
then
	echo "PIN must be 4 digits long - exiting"
	exit
fi

# Enter orgnisation bname"
export PREVORG=`grep "^ORGANISATION:" /usr/local/etc/scis_defaults |head -n 1 |awk -F":" '{print $2}'`
printf "Enter your organisation name (%s):" "${PREVORG}"
read ORGNAME
if [[ "${ORGNAME}" == "" ]]
then
	export ORGNAME="${PREVORG}"
fi

if [[ "${ORGNAME}" != "${PREVORG}" ]]
then
	grep -v "^ORGANISATION:" /usr/local/etc/scis_defaults > /usr/local/etc/scis_defaults_2
	echo "ORGANISATION:${ORGNAME}" >> /usr/local/etc/scis_defaults_2
	cp /usr/local/etc/scis_defaults_2 /usr/local/etc/scis_defaults
fi
# Script to setup TMZ System 
echo "Checking installed packages"
apt list --installed > /tmp/apt_list_installed

# Check nginx not installed
export N1=`grep "nginx-light" /tmp/apt_list_installed |wc -l`
if (( $N1 > 0 ))
then
	systemctl stop nginx-light
	apt remove nginx-light
fi

# Purge out lighttpd
apt-get purge lighttpd	 -y

# Install packages in sequence
# apt-get install php5 -y
apt-get install apache2 -y
aptitude install mysql-server mysql-client -y
aptitude install phpmyadmin php -y
aptitude install python2 -y
aptitude install python3-mysqldb -y

# Extract out /var/www/html
if [[ ! -d /var/www/html/menzshed ]]
then
	echo "Copying /var/www/html"
	cd ${WDIR}/var_www_html
	if [[ $? == "0" ]]
	then
		cp -rp * /var/www/html
	fi

	# Update organisation name
	sed -i "s/XORGANISATIONX/${ORGNAME}/g" /var/www/html/menzshed/index.php

	# Update apache2 config
	cd ${WDIR}/apache2
	if [[ $? == "0" ]]
	then
		diff apache2.conf /etc/apache2/apache2.conf 2>&1 > /dev/null
		export RC=$?
		if [[ "${RC}" != "0" ]]
		then
			cp -p apache2.conf /etc/apache2/apache2.conf
			systemctl restart apache2
		fi
	fi
fi

# Mysql
export PREVPASS=`grep "MYSQLPASS " /tmp/scratch_var |head -n 1|awk '{print $2}'`
if [[ "${PREVPASS}" != "" ]]
then
	echo "Enter mysql password (Or Return for previous):"
	read NEWPASS
else 	
	echo "Enter mysql password:"
	read NEWPASS
fi
if [[ "${NEWPASS}" == "" ]]
then
	export NEWPASS="${PREVPASS}"
else
	grep -v "^MYSQLPASS " /tmp/scratch_var > /tmp/scratch_var_2
	echo "MYSQLPASS ${NEWPASS}" >> /tmp/scratch_var_2
	cp /tmp/scratch_var_2 /tmp/scratch_var
fi

# try to get in
echo
echo "Scanning database for changes"
mysql -u root -p"${NEWPASS}" -e "show databases" > /tmp/work1

export I1=`grep information_schema  /tmp/work1 |wc -l`
if (( $I1 < 1 ))
then
	echo "Could not interrogate database - check and repair - exiting"
	exit
fi
export M1=`grep "menzshed" /tmp/work1 |wc -l`
if (( $M1 < 1 ))
then
	echo "Database not created - creating for you now"
	mysql -uroot -p"${NEWPASS}" < ${WDIR}/mysql/menzshed.sql
fi

# Check admin user present
mysql -u root -p"${NEWPASS}" -e "use menzshed;select first_name from member;"> /tmp/work1
export ADMINCNT=`grep "admin" /tmp/work1 |wc -l`
if (( $ADMINCNT < 1 ))
then
	echo "Admin User not present - creating for you now"
	cat ${WDIR}/mysql/setup_admin_user.sql |sed "s/XXXX/${PIN}/g" > /tmp/setup_admin_user.sql
	mysql -uroot -p"${NEWPASS}" < /tmp/setup_admin_user.sql
fi
	
# Check if user already present
mysql -u root -p"${NEWPASS}" -e "SELECT user,host FROM mysql.user;" > /tmp/work1
export M1=`grep "menzshed" /tmp/work1 |wc -l`
if (( $M1 < 1 ))
then
	echo "Menzshed User not created - creating now"
	mysql -uroot -p"${NEWPASS}" < ${WDIR}/mysql/userid.sql
fi

# Show output
echo "Script complete"
