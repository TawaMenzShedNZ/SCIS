#!/bin/bash

export TGTVER="10a"
if [[ -f ../tmz_${TGTVER}.tar.gz ]]
then
	rm -f ../tmz_${TGTVER}.tar.gz
fi

cd /home/fred/tmp/
tar -czvf tmz_${TGTVER}.tar.gz -T TMZ_Bundle/filelist
chown menzshed:menzshed *tar.gz
