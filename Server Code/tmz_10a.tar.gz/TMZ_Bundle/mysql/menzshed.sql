-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
-- Host: localhost    Database: 
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!50606 SET @OLD_INNODB_STATS_AUTO_RECALC=@@INNODB_STATS_AUTO_RECALC */;
/*!50606 SET GLOBAL INNODB_STATS_AUTO_RECALC=OFF */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
-- Current Database: `menzshed`
CREATE DATABASE /*!32312 IF NOT EXISTS*/ `menzshed` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `menzshed`;
-- Table structure for table `machine`
DROP TABLE IF EXISTS `machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `machine` (
  `machine_id` int NOT NULL AUTO_INCREMENT,
  `machine_wwn` varchar(20) NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `current_control` varchar(1) NOT NULL DEFAULT 'N',
  `cutoff_current` decimal(3,1),
  `cutoff_time`  decimal(3,1),
  PRIMARY KEY (`machine_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
-- Dumping data for table `machine`
-- Table structure for table `machine_log`
DROP TABLE IF EXISTS `machine_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `machine_log` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `machine_id` int NOT NULL,
  `machine_wwn` varchar(20) NULL,
  `log_in_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `log_out_time` timestamp NULL DEFAULT NULL,
  `log_status` varchar(10) NULL,
  `log_reason` varchar(50) NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=328 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
-- Table structure for table `member`
DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` text NOT NULL,
  `phone` varchar(25) NOT NULL,
  `tag_id` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `admin` varchar(1) NOT NULL DEFAULT 'N',
  `technician` varchar(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=226 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
-- Dumping data for table `member`
LOCK TABLES `member` WRITE;
UNLOCK TABLES;
-- Table structure for table `member_machine`
DROP TABLE IF EXISTS `member_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_machine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `machine_id` int NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mem_mac` (`member_id`,`machine_id`)
) ENGINE=MyISAM AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
-- Table structure for table `sign_in_register`
DROP TABLE IF EXISTS `sign_in_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sign_in_register` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `signin_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `signout_date_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1071 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
-- Table structure for table `util`
DROP TABLE IF EXISTS `util`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `util` (
  `id` int NOT NULL,
  `page` varchar(10) NOT NULL,
  `admin_access` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL DEFAULT 'n',
  `tag_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
-- Dumping data for table `util`
LOCK TABLES `util` WRITE;
/*!40000 ALTER TABLE `util` DISABLE KEYS */;
INSERT INTO `util` VALUES (1,'index','n','');
/*!40000 ALTER TABLE `util` ENABLE KEYS */;
UNLOCK TABLES;
