create user menzshed_user identified by 'password';
grant all privileges on *.* to 'menzshed_user'@'%';
