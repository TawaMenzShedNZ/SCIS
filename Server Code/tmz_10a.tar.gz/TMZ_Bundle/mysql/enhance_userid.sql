alter table member add technician varchar(1) default 'N';
