use menzshed;
alter table machine add machine_wwn varchar(20) NULL after machine_id;
alter table machine add current_control varchar(1) default 'N';
alter table machine add cutoff_current decimal(3,1) NOT NULL;
alter table machine add cutoff_time decimal(3,1) NOT NULL;
alter table member add technician varchar(1) default 'N';
alter table machine_log add machine_wwn varchar(20) NULL after machine_id;
alter table machine_log add log_status varchar(10) NULL after log_out_time;
alter table machine_log add log_reason varchar(50) NULL after log_status;
