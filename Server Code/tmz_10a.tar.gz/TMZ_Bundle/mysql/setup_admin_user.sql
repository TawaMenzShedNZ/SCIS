use menzshed;
LOCK TABLES `member` WRITE;
INSERT INTO `member` VALUES (3,'admin','','','','XXXX','Y','N');
UNLOCK TABLES;
