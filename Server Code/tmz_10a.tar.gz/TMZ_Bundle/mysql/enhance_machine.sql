alter table machine add machine_wwn varchar(20) NULL after machine_id;
alter table machine add current_control varchar(1) default 'N';
alter table machine add cutoff_current decimal(3,1) NOT NULL;
alter table machine add cutoff_time decimal(3,1) NOT NULL;
