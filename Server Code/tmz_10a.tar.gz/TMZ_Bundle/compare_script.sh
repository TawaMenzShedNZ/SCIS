#!/bin/bash

export PARM=$*
if [[ "${PARM}" == "" ]]
then
	echo "usage: dir1 dir2"
	exit
fi

export P1=`echo "${PARM}" |awk '{print $1}'`
export P2=`echo "${PARM}" |awk '{print $2}'`
if [[ ! -d "${P1}" ]]
then
	echo "${P1} not a dir"
	exit
fi
if [[ ! -d "${P2}" ]]
then
	echo "${P2} not a dir"
	exit
fi

cat /dev/null > /tmp/comp1
cd ${P1}
for i in $(ls -Al |grep -v "^d" |grep -v "^total" |awk '{print $NF}')
do
	export S1=`sum ${i} |awk '{print $1"_"$2}'`
	echo "P1 ${i} ${S1}" >> /tmp/comp1
done
cd ${P2}
for i in $(ls -Al |grep -v "^d" |grep -v "^total" | awk '{print $NF}')
do
	export S1=`sum ${i} |awk '{print $1"_"$2}'`
	echo "P2 ${i} ${S1}" >> /tmp/comp1
done


# Loop throught and compare
for i in $(cat /tmp/comp1 |awk '{print $2}' |sort -u)
do
	export S1=`grep "^P1 ${i} " /tmp/comp1 |awk '{print $3}'`
	export S2=`grep "^P2 ${i} " /tmp/comp1 |awk '{print $3}'`

	if [[ "${S1}" == "" ]]
	then
		export S1="XXX"
	fi
	if [[ "${S2}" == "" ]]
	then
		export S1="XXX"
	fi

	export MATCH=""
	if [[ "${S1}" != "${S2}" ]]
	then
		export MATCH="MISS"
	fi
	printf " %-20s | %10s | %10s | %s\n" ${i} ${S1} ${S2} "${MATCH}"
done

