<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//get parameters
$member_id = htmlspecialchars($_GET["id"]);

//update user details
$res = $shed->delUser($member_id);

session_start();

// Store data in session variables
$_SESSION["source"] = "del_user";
$_SESSION["result"] = $res;

// Redirect user to admin page
header("location: admin.php");
?>