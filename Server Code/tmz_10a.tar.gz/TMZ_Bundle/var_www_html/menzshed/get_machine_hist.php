<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//query database for a list of all machines that have been accessed

$sql = "SELECT b.name as machine_name 
	, a.machine_wwn as machine_wwn
	, DATE_FORMAT(a.log_in_time, '%d/%m/%Y') as date 
	, TIME_FORMAT(a.log_in_time, '%H:%i:%s') as start_time 
	, TIME_FORMAT(a.log_out_time, '%H:%i:%s') as end_time 
	, concat(c.first_name, ' ', c.last_name) as member_name 
	, a.log_status as log_status
	, a.log_reason as log_reason
	FROM machine_log a 
	left join machine b on a.machine_id = b.machine_id 
	left join member c on a.member_id = c.member_id 
	ORDER BY a.log_in_time DESC";


$stmt = $db->query($sql);

$table_rows='';

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$table_rows = $table_rows . "<tr><td>" . $row["machine_name"] . "</td><td>" . $row["machine_wwn"] . "</td><td>" . $row["date"] . "</td><td>" . $row["start_time"] . "</td><td>" . $row["end_time"] . "</td><td>" . $row["member_name"] . "</td><td>" . $row["log_status"] . "</td><td>" . $row["log_reason"] . "</td></tr>";
	}
}

$contents = '<table class="blueTable" id="register_table">
			<thead>
				<tr>
					<th>Machine Name</th>
					<th>Machine WWN</th>
					<th>Date</th>
					<th>Start Time</th>
					<th>End Time</th>
					<th>Member Name</th>
					<th>Log Status</th>
					<th>Log Reason</th>
				</tr>
			</thead>
			<tbody>' . $table_rows . '
			</tbody>
		</table>';

echo json_encode($contents);
$db->close();
?>
