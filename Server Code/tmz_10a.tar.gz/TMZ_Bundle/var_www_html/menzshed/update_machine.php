<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//get parameters
$m_name = htmlspecialchars($_GET["name"]);
$desc = htmlspecialchars($_GET["description"]);
$machine_id = htmlspecialchars($_GET["editmachineid"]);
$machine_wwn = htmlspecialchars($_GET["machine_wwn"]);

//update user details
$res = $shed->updateMach($machine_id, $m_name, $desc, $machine_wwn);

session_start();

// Store data in session variables
$_SESSION["source"] = "update_mach";
$_SESSION["result"] = $res;

// Redirect user to welcome page
header("location: admin.php");
?>
