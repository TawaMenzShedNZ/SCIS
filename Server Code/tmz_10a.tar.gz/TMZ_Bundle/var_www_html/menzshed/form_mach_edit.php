<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//get parameters
$param = htmlspecialchars($_GET["id"]);


//get a list of all the members and exclude admin user as this wont ever need to use a machine
$sql = "SELECT *
FROM machine a
where machine_id = ".$param ;



//execute query
$stmt = $db->query($sql);

$mach_id="";
$m_name="";
$desc="";
$machine_wwn="";

//create the option statement of list
if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$mach_id=$row["machine_id"];
		$m_name=$row["name"];
		$desc=$row["description"];
		$machine_wwn=$row["machine_wwn"];
	}
}

//create output
$contents = '
<div class="form-style-2">
<div class="form-style-2-heading">Edit Machine Details</div>
	<form action="update_machine.php" method="get">
		<input name="editmachineid" id="editmachineid" type="hidden" value="'. $param .'">
		<input name="txtValidWWN" type="hidden" id="txtValidWWN" value="">
		<label for="machid"><span>Machine ID</span><input id="form_name" type="text" name="machid" class="text" value="' . $mach_id . '" readonly></label>
		<label for="machname"><span>Machine Name</span><input id="form_name" type="text" name="name" class="input-field" required="required" data-error="Machine name is required." value="' . $m_name . '"></label>
		<label for="description"><span>Description</span><input id="form_desc" type="text" name="description" class="input-field" required="required" data-error="Description is required." value="' . $desc . '"></label>
		<label for="machine_wwn"><span>Machine WWN</span><input id="machine_wwn" type="text" name="machine_wwn" class="input-field"  value="' . $machine_wwn . '" oninput="validate_wwn_mod()"></label>
		<label for="readout_edit"<span></spam><input id="readout_edit" style="background-color: #71b8ca;border: 0px solid;color: red;font-size: 2em;" value="" readonly>
		<div class="form-buttons">
			<a class="button" href="">Cancel</a> <a class="button" href="del_mach.php?id=' . $param . '">Delete</a> <input type="submit" class="button" id="btnmachineedit" value="Update">
		</div>
	</form>
</div>';
echo json_encode($contents);
$db->close();
?>
