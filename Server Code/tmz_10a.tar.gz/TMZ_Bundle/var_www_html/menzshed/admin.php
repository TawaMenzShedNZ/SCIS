<?php
// Initialize the session
if(session_id() == '' || !isset($_SESSION) || session_status() === PHP_SESSION_NONE) {
    // session isn't started
    session_start();
	
}
// Check if the user is logged in, if not then redirect them to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: tag_login.php");
    exit;
}

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);
 
//set page value
$shed->assignPage('admin');
//clear tag id
$shed->clearTag();

# Generate data
$sql3 = mysqli_query($db, "SELECT member_id, concat(first_name, ' ', last_name) as full_name FROM member where admin = 'Y' and first_name != 'admin'" );
$data3 = $sql3->fetch_all(MYSQLI_ASSOC);

//get params if set
if(isset($_POST["type"])){
	$type = $_POST["type"];
}
else{
	//set empty values
	$type ="";
}
if(isset($_SESSION["source"])){
	$source = $_SESSION["source"];
	if(isset($_SESSION["result"])){
		$result = $_SESSION["result"];
	}
}
else{
	//set empty values
	$source = "";
	$result = "";
}
?>
<html>
<head>
	<link rel="stylesheet" href="css/index.css">
	<script src="js/jquery.min.js"></script>
	<script>
	let scanRefresh=0;
	
	function hideAll(){
		document.getElementById("user_add_form").style.display = "none";
                document.getElementById("tagid_div").style.display = "none";
                document.getElementById("tagid_cont").style.display = "none";
		document.getElementById("form_div").style.display = "none";
		document.getElementById("machine_btns_id").style.display = "none";
		document.getElementById("member_btns_id").style.display = "none";
		document.getElementById("signin_btns_id").style.display = "none";
		document.getElementById("register_div").style.display = "none";
		document.getElementById("form_cont").style.display = "none";
		document.getElementById("mach_access_memb").style.display = "none";
		document.getElementById("user_access_mach").style.display = "none";
		document.getElementById("machine_div").style.display = "none";
		document.getElementById("machine_rslt").style.display = "none";
		document.getElementById("machine_add_form").style.display = "none";
		
	}
	
	function signin() {
		clearInterval(scanRefresh);
		//hide elements
		hideAll();
		//show report buttons
		document.getElementById("signin_btns_id").style.display="block";
		//show table
		document.getElementById("register_div").style.display = "block";
		
		$.ajax({
			url: 'get_signins.php?type=1',
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#register_div').html(response);
			}
		});
	};
	

	function user_btns(){
		clearInterval(scanRefresh);
		//hide buttons
		hideAll();
		
		tableDiv = document.getElementById("register_div");
		member_menu = document.getElementById("member_btns_id");
		
		//show table
		tableDiv.style.display = "block";

		//show user/ member buttons
			member_menu.style.display = "block";
		//get user management
		$.ajax({
			url: 'get_users.php',
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#register_table').html(response);
			}
		});
	}
	
	//show machine list and sub buttons
	function machine_btns() {
		clearInterval(scanRefresh);
		//hide elements
		hideAll();
		document.getElementById("form_div").style.display="none";
		document.getElementById("form_cont").style.display="none";
		
		//show report buttons
		document.getElementById("machine_btns_id").style.display="block";
		//show table
		document.getElementById("register_div").style.display = "block";
		
		$.ajax({
			url: 'get_machine_list.php',
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#register_div').html(response);
			}
		});
	}

	//show machine useage history
	function machine_hist() {
		clearInterval(scanRefresh);
		//hide buttons
		hideAll();
		
		document.getElementById("register_div").style.display="block";
		document.getElementById("register_table").innerHtml = "";
		// tableDiv = document.getElementById("register_div");
		
		//show table
		// tableDiv.style.display = "block";
				
		$.ajax({
			url: 'get_machine_hist.php',
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#register_table').html(response);
			}
		});
	};
	
	//show machine access form
	function machine_access(id){
		clearInterval(scanRefresh);
		hideAll();
		
		//show form
		document.getElementById("form_div").style.display = "flex";
		document.getElementById("mach_access_memb").style.display = "block";
		
		//hide table
		document.getElementById("register_div").style.display = "none";
		
		$.ajax({
			url: 'form_mach_access.php?id='+id,
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#mach_access_memb').html(response);
			}
		});
	};
	
        function user_machine_access(id) {
		clearInterval(scanRefresh);
		hideAll();
		//show form
		//hide table
		document.getElementById("register_div").style.display = "none";
		document.getElementById("form_div").style.display = "flex"; 
		document.getElementById("form_cont").style.display = "block"; // was block
		// document.getElementById("user_access_mach").style.display = "flex"; // was flex

		$.ajax({
			url: 'form_user_access.php?id='+id,
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#form_cont').html(response);
			}
		});  
	
		/* clearInterval(scanRefresh);
		hide table
		hideAll();
		document.getElementById("register_div").style.display = "none";
		document.getElementById("user_add_form").style.display = "none";
		document.getElementById("machine_div").style.display = "none";
		document.getElementById("machine_rslt").style.display = "none";
		//show form
		document.getElementById("form_div").style.display = "flex";
		document.getElementById("form_cont").style.display = "block";


		//show form to edit user details
		// was form_user_edit.php */
		/* $.ajax({
			url: 'form_mach_edit.php?id=6,'
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#form_cont').html(response);
			}
		}); */ 
		/* $.ajax({
			url: 'form_user_access.php?id='+id,
			url: 'form_user_edit.php?id='+id,
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#form_cont').html(response);
			}
		});
		*/
        };

	//display list of all machines
	function machine_list(){
		clearInterval(scanRefresh);
		//show table
		document.getElementById("register_div").style.display = "block";
		//hide form
		document.getElementById("form_div").style.display = "none";
		
		//display table
		$.ajax({
			url: 'get_machine_list.php',
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#register_div').html(response);
			}
		});
	};
	
	//show form to add a machine
	function add_machine(){
		clearInterval(scanRefresh);		
		//hide table
		document.getElementById("register_div").style.display = "none";
		document.getElementById("form_div").style.display = "none";
		//show form
		document.getElementById("machine_add_form").style.display = "flex";
	};
	
	function mach_edit(id){
		clearInterval(scanRefresh);		
		
		//hide table
		hideAll();
		document.getElementById("register_div").style.display = "none";
		
		//show form
		document.getElementById("form_div").style.display = "flex";
		document.getElementById("form_cont").style.display = "block";
		
		$.ajax({
			url: 'form_mach_edit.php?id='+id,
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#form_cont').html(response);
			}
		});
	};
	
	
	//user table buttons
	function user_edit(id){
		clearInterval(scanRefresh);
		//hide table
		hideAll();
		document.getElementById("register_div").style.display = "none";
		document.getElementById("user_add_form").style.display = "none";
		document.getElementById("machine_div").style.display = "none";
		document.getElementById("machine_rslt").style.display = "none";
		//show form
		document.getElementById("form_div").style.display = "flex";
		document.getElementById("form_cont").style.display = "block";


		//show form to edit user details
		$.ajax({
			url: 'form_user_edit.php?id='+id,
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#form_cont').html(response);
			}
		});
	}
	
	//user table buttons
	function user_add(){
		clearInterval(scanRefresh);
		//hide table
		document.getElementById("register_div").style.display = "none";
		document.getElementById("form_div").style.display = "block";
		//show form
		document.getElementById("user_add_form").style.display = "flex";
		document.getElementById("machine_div").style.display = "none";
		document.getElementById("machine_rslt").style.display = "none";
	}
	
	function scan_tag_btn(){
		//hide buttons
		hideAll();
		document.getElementById("user_add_form").style.display = "none";
		document.getElementById("machine_div").style.display = "none";
		document.getElementById("machine_rslt").style.display = "none";
		document.getElementById("register_div").style.display = "none";
		document.getElementById("machine_btns_id").style.display = "none";
		document.getElementById("member_btns_id").style.display = "none";
		
		document.getElementById("tagid_div").style.display = "flex";
		document.getElementById("tagid_cont").style.display = "block";
		
		scanRefresh = setInterval(function() {
		  $.ajax({
				url: 'fetch_tag_id.php',
				method: "GET",
				dataType: 'json',
					success: function(response) {
					   $('#tagid_cont').html(response);
					}
				});
		}, 2000);//refresh every 2 secs
		
		$.ajax({
			url: 'fetch_tag_id.php',
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#tagid_cont').html(response);
			}
		});
		
	}
	
	function scan_machine_btn(){
		//hide buttons
		hideAll();
		document.getElementById("user_add_form").style.display = "none";
		document.getElementById("register_div").style.display = "none";
		document.getElementById("machine_btns_id").style.display = "none";
		document.getElementById("member_btns_id").style.display = "none";
		
		document.getElementById("form_div").style.display = "none";
		document.getElementById("form_cont").style.display = "none";
		document.getElementById("machine_div").style.display = "flex";
		document.getElementById("machine_rslt").style.display = "flex";
		document.getElementById("machine_head").style.display = "block";
		document.getElementById("machine_cont").style.display = "block";
		
                scanRefresh = setInterval(function() {
                    $.ajax({
                                url: 'fetch_machine_wwn.php',
                                method: "GET",
                                dataType: 'json',
                                data: { member_id: document.getElementById("admin_dropdown").value,
                                        last_log_id: document.getElementById("txtLastLogId").value },
                                success: function(response) {
                                $('#machine_rslt').html(response);
                              }
                           });
                }, 2000);//refresh every 2 secs

	}
	
         function find_last_log() {
                console.log("made into find_last_log");
                // function to find last database log;
                // call ajax function to query database on last value in machine_log
                $.ajax({
                            url: 'find_last_log_id.php',
                            method: "GET",
                            success: function(response) {
                                console.log("response");
                                console.log(response);
                                document.getElementById("txtLastLogId").value = response;
                                $('#machine_rslt').html("");
                          }
                       });
		scan_machine_btn();
	}

	function validate_wwn_add() {
                console.log("made into validate_wwn_add");
                $.ajax({
                            url: 'validate_wwn_add.php',
                            method: "GET",
                            async: false,
 			    dataType: 'json',
                            data: { machine_id: '0',
				 machine_wwn: document.getElementById('machine_wwn').value },
                            success: function(response) {
                                console.log("response");
                                console.log(response);
                                document.getElementById("txtValidWWN").value = response;
				}
                       });
                console.log("validate_wwn_add - found");
                console.log(document.getElementById("txtValidWWN").value);
		if ( document.getElementById("txtValidWWN").value != "0" )
		{
			document.getElementById("btnmachineadd").disabled = true;
			document.getElementById("btnmachineadd").style.backgroundColor = "#808080";
			document.getElementById("readout_add").value = "WWN in use already";
		} else {
			document.getElementById("btnmachineadd").disabled = false;
			document.getElementById("btnmachineadd").style.backgroundColor = "#04AA6D";
			document.getElementById("readout_add").value = "";
		}
	}

	function validate_wwn_mod() {
                console.log("made into validate_wwn_mod");
                $.ajax({
                            url: 'validate_wwn_mod.php',
                            method: "GET",
                            async: false,
 			    dataType: 'json',
                            data: { machine_id: document.getElementById('editmachineid').value,
					machine_wwn: document.getElementById('machine_wwn').value },
                            success: function(response) {
                                console.log("response");
                                console.log(response);
                                document.getElementById("txtValidWWN").value = response;
				}
                       });
                console.log("validate_wwn_mod - found");
                console.log(document.getElementById("txtValidWWN").value);
		if ( document.getElementById("txtValidWWN").value != "0" )
		{
			document.getElementById("btnmachineedit").disabled = true;
			document.getElementById("btnmachineedit").style.backgroundColor = "#808080";
			document.getElementById("readout_edit").value = "WWN in use already";
		} else {
			document.getElementById("btnmachineedit").disabled = false;
			document.getElementById("btnmachineedit").style.backgroundColor = "#04AA6D";
			document.getElementById("machine_wwn").setCustomValidity('');
			document.getElementById("readout_edit").value = "";
		}
	}

	//Report Buttons
	function view_report(){ //show the summary report
		hideAll();
		//show table
		document.getElementById("register_div").style.display = "block";
		
		$.ajax({
			url: 'view_report.php',
			method: "GET",
			dataType: 'json',
			success: function(response) {
			   $('#register_div').html(response);
			}
		});
	}
	
	function export_data(){
		//hideAll();
		window.location.href='export_data.php';
		alert('Export file created in download folder');
	}
	</script>
	<title>TM Admin</title>
</head>
<body style="background-color:#71b8ca!important;" onload="hideAll();">
	<div class="logo">
		<img src="images/Logo.jpg" class="logo">
	</div>
	<div class="welcome-wrap">
		<div class="welcome-content">
			<h1>Admin</h1>
		</div>
	</div>
	<div class="sticky-menu" id="menu">
		<p><a class="button" href="javascript:signin();">View sign-in history</a>
		<a class="button" href="javascript:machine_hist();">View Machine Use History</a>
		<a class="button" href="javascript:machine_btns();">Machine Management</a>
		<a class="button" href="javascript:user_btns();">User Management</a>
		<a class="button" href="javascript:scan_tag_btn();">Scan Tag</a>
		<a class="button" href="javascript:scan_machine_btn();">Scan Machine</a>
		<a class="button" disabled>Audit Log</a>
		<a class="button" href="logout.php">Logout</a></p>
	</div>
	<div class="sub_buttons" id="signin_btns_id">
		<p>
			<a class="button" href="javascript:view_report();">View Report</a>
			<a class="button" href="javascript:export_data();">Export Sign-in Data</a>
		</p>
	</div>
	<div class="sub_buttons" id="machine_btns_id">
		<p>
			<a class="button" href="javascript:add_machine();">Add a Machine</a>
		</p>
	</div>
	<div class="sub_buttons" id="member_btns_id">
		<p>
			<a class="button" href="javascript:user_add();">Add a Member</a>
			<a class="button" href="">Import Members</a>
		</p>
	</div>
	<div class="register" id="register_div">
		<table class="blueTable" id="register_table">
		</table>
	</div>
	<div class="form-wrapper" id="form_div">
		<div class="form-content" id='form_cont'>
		</div>
		<div class="form-content-user-list" id ="mach_access_memb" style="display:none">
		</div>
	</div>
	<div class="form-wrapper" id="form_div">
		<div class="form-content" id='form_cont'>
		</div>
		<div class="form-content-machine-list-scroll" id ="user_access_mach" style="display:none">
		</div>
	</div>
	<div class="form-wrapper" id="tagid_div">
		<div class="form-content" id='tagid_cont'>
		</div>
	</div>
       <div class="form-wrapper" id="machine_div">
                <div class="form-content" id='machine_head'>
                <h2>Scan Box with selected Tag</h2>
		<table>
		 <tr> 
		   <td align="right">
		    <label for='admin_dropdown'>Select Admin User:</label>
		   </td>
		   <td align="left">
                    <select name="admin_dropdown" id="admin_dropdown" onChange="find_last_log()">
                      <option value=""></option>
                      <?php foreach($data3 as $row): ?>
                      <option value="<?= htmlspecialchars($row['member_id']) ?>">
                      <?= htmlspecialchars($row['full_name']) ?>
                      </option>
                      <?php endforeach ?>
                      </select>
		   </td>
	   	  </tr>
	   	  <tr>
                     <input type="hidden" id="txtLastLogId">
                  </tr> 
                 </table>
                </div>
        </div>
        <div class="form-wrapper" id="machine_rslt">
                <div class="form-content" id='machine_cont'>
                </div>
        </div>
	<div class="form-wrapper" id="user_add_form" style="display:none">
		<div class="form-content">
			<div class="form-style-2" >
				<div class="form-style-2-heading" id='form_cont'>Add Member</div>
				<form action="add_user.php" method="get"> 
					
						<label for="first_name"><span>First Name</span>
						<input type="text" name="first_name" value=""></label>
						<label for="last_name"><span>Last Name</span>
						<input type="text" name="last_name" value=""></label>
						<label for="email"><span>Email</span><input type="text" name="email" value=""></label>
						<label for="phone"><span>Phone</span><input type="text" name="phone" value=""></label>
						<label for="admin"><span>Admin</span> <input type="radio" id="admin_no" name="admin" value="N" checked>No
						<input type="radio" name="admin" id="admin_yes" value="Y"> Yes</label>
						<label for="tag_id"><span>Tag ID</span>
						<input type="text" name="tag_id" value=""></label>
					
					<div class="form-buttons">
						<a class="button" href="">Cancel</a> <a class="button" href="">Delete</a><input type="submit" class="button" value="Add">
					</div>
				</form>
			</div>
		</div>
	</div>
	
	<div class="form-wrapper" id="machine_add_form" style="display:none">
		<div class="form-content">
			<div class="form-style-2" >
				<div class="form-style-2-heading" id='form_cont'>Add Machine</div>
				<p><input type="hidden" id="txtValidWWN"</p>
				<form action="add_mach.php" method="get">
						<label for="mach_name"><span>Machine Name</span>
						<input type="text" name="mach_name" value=""></label>
						<label for="description"><span>Description</span>
						<input type="text" name="description" value=""></label>					
						<label for="machine_wwn"><span>Machine WWN</span>
						<input type="text" name="machine_wwn" id="machine_wwn" value="" oninput="validate_wwn_add()"></label>					
						<label for="readout_add"<span></spam><input id="readout_add" style="background-color: #71b8ca;border: 0px solid;color: red;font-size: 2em;" value="" readonly>
					<div class="form-buttons">
						<a class="button" href="">Cancel</a> <input type="submit" class="button" id="btnmachineadd" value="Add">
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php
	
	//Code to display message after adding or editing database record
	$msg="";
	$msg_header="";
	//updated user
	if($source=="update_user"){
		if($result == "1"){
				$msg = "User details updated";
				$msg_header="<div class='alert success'>";
			}
			else{
				$msg = "<strong>Error!</strong>Couldn't update member details";
				$msg_header="<div class='alert'>";
			}
		
			//display results
			echo $msg_header;
			?>
			<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
			<?php
			echo $msg.'</div>';
	}
	//User added
	else if ($source =="add_user"){
		if($result== "1"){
			$msg = "A new member has been added";
			$msg_header="<div class='alert success'>";
		}
		else {
			$msg = "<strong>Error!</strong>Could not add member";
			$msg_header="<div class='alert'>";
		}
		
		//display results
		echo $msg_header;
?>
	<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
<?php
		echo $msg.'</div>';
	}
	//delete user 
	else if ($source =="del_user"){
		if($result== "1"){
			$msg = "Member has been deleted";
			$msg_header="<div class='alert success'>";
		}
		else {
			$msg = "<strong>Error!</strong>Could not delete member";
			$msg_header="<div class='alert'>";
		}
		
		//display results
		echo $msg_header;
?>
	<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
<?php
		echo $msg.'</div>';
	}
	//machine access
	else if ($source == "mach_access"){
		if($result == "0"){
			$msg = "User already has access";
			$msg_header="<div class='alert Info'>";
		}
		else if($result == "1"){
			$msg = "Access updated";
			$msg_header="<div class='alert success'>";
		}
		else{
			$msg = "<strong>Error!</strong>Could not add access";
			$msg_header="<div class='alert'>";
		}
	
		//display results
		echo $msg_header;
?>
	<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
<?php
		echo $msg.'</div>';
	}
	
	else if($source == "add_mach"){
		if($result== "1"){
			$msg = "A new machine has been added";
			$msg_header="<div class='alert success'>";
		}
		else {
			$msg = "<strong>Error!</strong>Could not add machine";
			$msg_header="<div class='alert'>";
		}
	
		//display results
		echo $msg_header;
?>
	<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
<?php
		echo $msg.'</div>';
	}
	
	else if($source == "update_mach"){
		if($result== "1"){
			$msg = "Machine details updated";
			$msg_header="<div class='alert success'>";
		}
		else {
			$msg = "<strong>Error!</strong>Could not update machine details";
			$msg_header="<div class='alert'>";
		}
	
		//display results
		echo $msg_header;
?>
	<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
<?php
		echo $msg.'</div>';
	}
	
	else if($source == "del_mach"){
		if($result== "1"){
			$msg = "Machine has been deleted";
			$msg_header="<div class='alert success'>";
		}
		else {
			$msg = "<strong>Error!</strong>Could not delete machine";
			$msg_header="<div class='alert'>";
		}
	
		//display results
		echo $msg_header;
?>
	<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
<?php
		echo $msg.'</div>';
	}
	
	else if($source == "export"){
		if($result == "1"){
			$msg = "Data has been exported";
			$msg_header="<div class='alert Info'>";
		}
		else{
			$msg = "<strong>Error!</strong>Sorry, Export failed";
			$msg_header="<div class='alert'>";
		}
	
		//display results
		echo $msg_header;
?>
	<span class='closebtn' onclick="this.parentElement.style.display='none';">&times;</span>
<?php
		echo $msg.'</div>';
	}
	
	//Reset source and result values
	$source='';
	$result='';
	$_SESSION["source"]="";
	$_SESSION["result"]="";
	?>
	<p>&nbsp;</p>
	
	<script>
		// When the user scrolls the page, execute myFunction
		window.onscroll = function() {myFunction()};

		// Get the menu
		var menu = document.getElementById("menu");

		// Get the offset position of the navbar
		var sticky = menu.offsetTop;

		// Add the sticky class to the menu when you reach its scroll position. Remove "sticky" when you leave the scroll position
		function myFunction() {
		  if (window.pageYOffset > sticky) {
			menu.classList.add("sticky");
		  } else {
			menu.classList.remove("sticky");
		  }
		}
	
		
</script>
</body>
<footer>
</footer>
</html>
