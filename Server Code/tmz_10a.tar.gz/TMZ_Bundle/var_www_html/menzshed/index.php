<?php
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);
 
//set page value
$shed->assignPage('index');
?>
<html>
<head>
	<link rel="stylesheet" href="css/index.css">
	<script src="js/jquery.min.js"></script>
	<script>
		var table = $("#register_table");

		// refresh every 5 seconds
		var refresher = setInterval(function() {
		  $.ajax({
				url: 'get_signins.php?type=',
				method: "GET",
				dataType: 'json',
					success: function(response) {
					   $('#register_table').html(response);
					}
				});
		}, 5000);
		
		$.ajax({
				url: 'get_signins.php?type=',
				method: "GET",
				dataType: 'json',
					success: function(response) {
					   $('#register_table').html(response);
					}
				});
	</script>
	<title>Menzshed</title>
</head>
<body style="background-color:#71b8ca!important;">
	<div class="logo">
		<img src="images/Logo.jpg" class="logo">
	</div>
	<div class="welcome-wrap">
		<div class="welcome-content">
			<h1>Welcome to XORGANISATIONX</h1>
			<p class="welcome">Please sign in before starting on your project or using any of the machines.</p>
			<p class="welcome">Tap your MenzShed tag over the sign-in device.</p>
		</div>
	</div>
	<div class="sticky-menu" id="menu">
		<p><a class="button" href="tag_login.php">Admin</a></p>
	</div>
	<div class="register_signin">
		<h1>Sign-in Register for <?php echo date("d-m-Y")?></h1>
		<table class="blueTable" id="register_table">
			<thead>
				<tr>
					<th>Name</th>
					<th>Sign In Time</th>
					<th>Sign Out Time</th>
				</tr>
			</thead>
			<tfoot>
				<tr>
				<td colspan="4">
				<div class="links"><a href="#">&laquo;</a> <a class="active" href="#">1</a> <a href="#">2</a> <a href="#">3</a> <a href="#">4</a> <a href="#">&raquo;</a></div>
				</td>
				</tr>
			</tfoot>
			<tbody>
				<tr>
					<td></td>
					<td></td>
					<td></td>
				</tr>		
			</tbody>
		</table>
	</div>
	<p>&nbsp;</p>
	
	<script>
		// When the user scrolls the page, execute myFunction
		window.onscroll = function() {myFunction()};

		// Get the menu
		var menu = document.getElementById("menu");

		// Get the offset position of the navbar
		var sticky = menu.offsetTop;

		// Add the sticky class to the menu when you reach its scroll position. Remove "sticky" when you leave the scroll position
		function myFunction() {
		  if (window.pageYOffset > sticky) {
			menu.classList.add("sticky");
		  } else {
			menu.classList.remove("sticky");
		  }
		}
	</script>
</body>
<footer>
</footer>
</html>
