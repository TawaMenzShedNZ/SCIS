<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//get parameters
$param = htmlspecialchars($_GET["id"]);


//get a list of all the members and exclude admin user as this wont ever need to use a machine
$sql = "SELECT *
FROM member a
where member_id = ".$param ;



//execute query
$stmt = $db->query($sql);

$f_name="";
$l_name="";
$email="";
$phone="";
$tagid="";
$admin="";
//create the option statement of list
if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$f_name=$row["first_name"];
		$l_name=$row["last_name"];
		$email=$row["email"];
		$phone=$row["phone"];
		$tagid=$row["tag_id"];
		$admin=$row["admin"];
	}
}

$checked_yes='';
$checked_no='';

if ($admin=='Y'){
	$checked_yes = 'checked';
}
else{
	$checked_no='checked';
}
//create output
$contents = '
<div class="form-style-2">
<div class="form-style-2-heading">Edit Member Details</div>
	<form action="update_user.php" method="get">
		<input name="id" type="hidden" value="'. $param .'">
		<label for="firstname"><span>First Name</span><input id="form_name" type="text" name="firstname" class="input-field" required="required" data-error="Firstname is required." value="' . $f_name . '"></label>
		<label for="surname"><span>Last Name</span><input id="form_lastname" type="text" name="surname" class="input-field" required="required" data-error="Lastname is required." value="' . $l_name . '"></label>
		<label for="email"><span>Email</span><input id="form_email" type="email" name="email" class="input-field" value="' . $email . '"></label>
		<label><span>Phone</span><input id="form_phone" type="tel" name="phone" class="tel-number-field" max=20 value="' . $phone . '"></label>
		<label for="admin"><span>Admin</span> <input type="radio" id="admin_no" name="admin" value="N" '. $checked_no . '>No<input type="radio" name="admin" id="admin_yes" value="Y" '. $checked_yes. '> Yes
		</label>
		<label><span>Tag ID</span><input type="text" name="tag_id" value="' . $tagid . '"></label>
		<div class="form-buttons">
			<a class="button" href="">Cancel</a> <a class="button" href="del_user.php?id=' . $param . '">Delete</a> <input type="submit" class="button" value="Update">
		</div>
	</form>
</div>';
echo json_encode($contents);
$db->close();
?>
