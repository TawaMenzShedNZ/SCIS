<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//get parameters
$machine_id = htmlspecialchars($_GET["id"]);

//update user details
$res = $shed->delMach($machine_id);

session_start();

// Store data in session variables
$_SESSION["source"] = "del_mach";
$_SESSION["result"] = $res;

// Redirect user to admin page
header("location: admin.php");
?>