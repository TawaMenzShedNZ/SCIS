<?php

// FInd out if WWMN already used
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

$varMachineID = $_GET['machine_id'];
$varMachineWWN = $_GET['machine_wwn'];

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//set page
$shed->assignPage('tag');

//get tag id from util table
$sql = "select * from machine where machine_wwn = '" . $varMachineWWN . "'";

//execute statement
$stmt = $db->query($sql);

// get count
$rowcnt = $stmt->num_rows;
echo $rowcnt;

// $log_id = $row['log_id'];
// if ($log_id == NULL)
// { // set to zero
// $log_id=0;
// }
// echo $row['log_id'];
// if ( $varMachineWWN == '111' )
// { echo "1"; 
// } else {
// echo "0";
// }

$db->close();
?>
