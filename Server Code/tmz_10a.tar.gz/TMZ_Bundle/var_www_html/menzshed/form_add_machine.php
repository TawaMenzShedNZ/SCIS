<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();


//create output
$contents = '<h2>Add a Machine</h2>
			<p>Add a new machine</p>
			<form action="" method="post">
				<input type="hidden" name="source" value="add_mach">
				<div class="form-group">
					<label for="machine_name">Machine Name: </label>
					<input type="text" name="input1" required> 
					<label for="machine_description">Description:</label>
					<input type="text" name="input2" required>
				</div>
				<div class="form-buttons">
					<input type="submit" class="button" value="Add">
				</div>
			</form>';

echo json_encode($contents);
$db->close();
?>