<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//get a list of the machines and their descriptions

$sql = "SELECT machine_id
	, a.name as machine_name 
	, a.machine_wwn as machine_wwn 
	, a.description
	FROM machine a 
	ORDER BY a.name";


$stmt = $db->query($sql);

$table_rows='';

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$table_rows = $table_rows . "<tr><td>" . $row["machine_name"] . "</td><td>" . $row["machine_id"] . "</td><td>" . $row["machine_wwn"] . "</td><td>" . $row["description"] . "</td><td><a class='button' href='javascript:mach_edit(" . $row["machine_id"] . ");'>Edit</a></td><td><a class='button' href='javascript:machine_access(" . $row["machine_id"] . ");'>Access</a></td></tr>";
	}
}

$contents = '<table class="blueTable" id="register_table">
			<thead>
				<tr>
					<th>Machine Name</th>
					<th>Machine ID</th>
					<th>Machine WWN</th>
					<th>Description</th>
					<th colspan="2">Options</th>
					
				</tr>
			</thead>
			<tbody>' . $table_rows . '
			</tbody>
		</table>';

echo json_encode($contents);
$db->close();
?>
