<?php
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);
 
 
$stmt = $shed->get_avg_summary();

$summary_rows='';

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$summary_rows = $summary_rows . "<tr><td>" . $row["day"] . "</td><td>" . $row["avg_attend"] . "</td></tr>";
	}
}

$stmt = $shed->get_day_summary();
$day_rows='';

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$day_rows = $day_rows . "<tr><td>" . $row["day"] . "</td><td>" . $row["sign_in_Date"] . "</td><td>" . $row["num_attendees"] . "</td></tr>";
	}
}

$contents = '<h2>Average Attendance <br>for each day the shed is open</h2>
<table class="blueTable" id="register_table">
	<thead>
		<tr>
			<th>Day</th>
			<th>Average Attendance</th>
		</tr>
	</thead>
	<tbody>' . $summary_rows . '
	</tbody>
</table>
<br>
<h2>Daily summary</h2>
<table class="blueTable" id="register_table">
	<thead>
		<tr>
			<th>Day</th>
			<th>Date</th>
			<th>Attendance Count</th>
		</tr>
	</thead>
	<tbody>' . $day_rows . '
	</tbody>
</table>';

echo json_encode($contents);
 $db->close();
?>