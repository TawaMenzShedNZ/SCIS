<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//get parameters
$first_name = htmlspecialchars($_GET["firstname"]);
$surname = htmlspecialchars($_GET["surname"]);
$email = htmlspecialchars($_GET["email"]);
$phone = htmlspecialchars($_GET["phone"]);
$admin = htmlspecialchars($_GET["admin"]);
$member_id = htmlspecialchars($_GET["id"]);
$tag_id = htmlspecialchars($_GET["tag_id"]);

//update user details
$res = $shed->updateUser($member_id, $first_name, $surname, $email, $phone, $tag_id, $admin);

session_start();

// Store data in session variables
$_SESSION["source"] = "update_user";
$_SESSION["result"] = $res;

// Redirect user to welcome page
header("location: admin.php");
?>
