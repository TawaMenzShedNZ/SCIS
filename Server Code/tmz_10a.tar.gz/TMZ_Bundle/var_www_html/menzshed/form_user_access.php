<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//get id
$member_id = htmlspecialchars($_GET["id"]);
$member_name = "";

//get machine name AAAAA done to here
$sql = "SELECT concat(first_name, ' ', last_name) as name FROM member where member_id = " . $member_id;

//execute query
$stmt = $db->query($sql);
if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$member_name = $row["name"];
	}
}

//get a list of all the members and exclude admin user as this wont ever need to use a machine
$sql = "SELECT ma.name
    , ma.machine_id
    , mm.member_id as has_access
FROM machine ma
LEFT JOIN member_machine mm on ma.machine_id = mm.machine_id and mm.member_id= " . $member_id ."
order by ma.name";

//execute query
$stmt = $db->query($sql);

$user_select='';

//create the option statement of list
if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		//check if user has access
		if (!empty($row["has_access"])) {
			//set checkbox to checked as user has access
			$user_select = $user_select . "<input type='checkbox' id='" . $row["machine_id"] . "' name='access[" . $row["machine_id"] . "]' value='" . $row["machine_id"] . "' checked>
			<label class='user_list' for='" . $row["machine_id"] . "'>" . $row["name"] . "</label><br>";
		}
		else {
			$user_select = $user_select . "<input type='checkbox' id='" . $row["machine_id"] . "' name='access[" . $row["machine_id"] . "]' value='" . $row["machine_id"] . "'>
			<label class='user_list' for='" . $row["machine_id"] . "'>" . $row["name"] . "</label><br>";
		}
	}
}

//create output
$contents = '<h2>User Access for '. $member_name . '</h2>
			<p>Give any number of members access to the machine</p>
			<form action="add_user_access.php" method="post"> 
                        <div class="column" width=100px height=300px>
				<input type="hidden" name="source" value="user_access">
				<input type="hidden" name="member_id" value="'.$member_id.'">
				<div class="form-content-user-list-scroll" float="left">
						' . $user_select . '
			        </div>
			        <div class="form-content-machine-button-noscroll">
			   	   <a class="button" href="">Cancel</a>
				   <input type="submit" class="button" value="Grant Access">
			        </div>
			</div>
			</form>';

echo json_encode($contents);
$db->close();
?>
