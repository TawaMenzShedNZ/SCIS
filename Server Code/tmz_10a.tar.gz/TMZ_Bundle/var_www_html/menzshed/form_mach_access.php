<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//get id
$machine_id = htmlspecialchars($_GET["id"]);
$machine_name = "";

//get machine name
$sql = "SELECT name FROM machine where machine_id = " . $machine_id;

//execute query
$stmt = $db->query($sql);
if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$machine_name = $row["name"];
	}
}

//get a list of all the members and exclude admin user as this wont ever need to use a machine
$sql = "SELECT concat(first_name, ' ', last_name) as name
    , a.member_id
    , mm.member_id as has_access
FROM member a
LEFT JOIN member_machine mm on a.member_id = mm.member_id and mm.machine_id= " . $machine_id ."
where a.first_name != 'admin'
order by first_name";

//execute query
$stmt = $db->query($sql);

$member_select='';

//create the option statement of list
if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		//check if user has access
		if (!empty($row["has_access"])) {
			//set checkbox to checked as user has access
			$member_select = $member_select . "<input type='checkbox' id='" . $row["member_id"] . "' name='access[" . $row["member_id"] . "]' value='" . $row["member_id"] . "' checked>
			<label class='user_list' for='" . $row["member_id"] . "'>" . $row["name"] . "</label><br>";
		}
		else {
			$member_select = $member_select . "<input type='checkbox' id='" . $row["member_id"] . "' name='access[" . $row["member_id"] . "]' value='" . $row["member_id"] . "'>
			<label class='user_list' for='" . $row["member_id"] . "'>" . $row["name"] . "</label><br>";
		}
	}
}

//create output
$contents = '<h2>Machine Access for '. $machine_name . '</h2>
			<p>Give any number of members access to the machine</p>
			<form action="add_mach_access.php" method="post"> 
                        <div class="column" width=100px height=300px>
				<input type="hidden" name="source" value="mach_access">
				<input type="hidden" name="machine_id" value="'.$machine_id.'">
				<div class="form-content-user-list-scroll" float="left">
						' . $member_select . '
			        </div>
			        <div class="form-content-machine-button-noscroll" float="left">
			   	   <a class="button" href="">Cancel</a>
				   <input type="submit" class="button" value="Grant Access">
			        </div>
			</div>
			</form>';

echo json_encode($contents);
$db->close();
?>
