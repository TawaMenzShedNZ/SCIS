<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//set page
$shed->assignPage('tag');

//get tag id from util table
$sql = "SELECT tag_id FROM util a";

//execute statement
$stmt = $db->query($sql);

$tag_id='';

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$tag_id = str_replace('"','',$row['tag_id']);
	}
}
//echo $tag_id . "returned";
$contents = '<form id="tag_form">			
				<h2>Scan Tag</h2>
				<p>Please scan your Menzshed tag to ascertain its ID</p>
				<div class="form-group">
					<label for="tag_id">Tag ID:</label>
					<input type="text" id="tag_id" name="tag_id" value="' . $tag_id . '" readonly><br>
				</div>
				<div class="form-buttons">
					<a class="button" href="admin.php">Cancel</a> <a class="button" href="javascript:copyText();">Copy Tag</a>
				</div>
			</form>
			
			<script>
			function copyText(){
				let tagInput = document.querySelector("input");
				
				navigator.clipboard.writeText(tagInput.value).then(res=>{
					console.log("Tag ID copied to clipboard");
				});
			}
			</script>';

echo json_encode($contents);
$db->close();
?>