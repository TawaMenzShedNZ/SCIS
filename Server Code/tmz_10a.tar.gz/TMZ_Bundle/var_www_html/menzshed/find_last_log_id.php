<?php

// Find last log id
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//set page
$shed->assignPage('tag');

//get tag id from util table
$sql = "select log_id from machine_log order by log_id desc limit 1";

//execute statement
$stmt = $db->query($sql);
if ($stmt->num_rows==0){
	$log_id=0;
} else 
{
	$row = $stmt->fetch_assoc();
	$log_id = $row['log_id'];
}
echo $log_id;
$db->close();
?>
