<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
//Oct 23: add member access button - IanD
$database = new Database();
$db = $database->connect();


//get all members
$sql = "SELECT concat(a.first_name, ' ', a.last_name) as name
			, a.email
			, a.phone
			, a.tag_id
			, a.admin
			, a.member_id
		FROM member a
		where first_name != 'admin'
		order by concat(a.first_name, ' ', a.last_name)";

$stmt = $db->query($sql);

$table_rows='';

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$table_rows = $table_rows . "<tr><td>" . $row["name"] . "</td><td>" . $row["email"] . "</td><td>" . $row["phone"] . "</td><td>" . $row["tag_id"] . "</td><td>" . $row["admin"] . "</td><td><a class='button' href='javascript:user_edit(" . $row["member_id"] . ");'>Edit</a></td><td><a class='button' href='javascript:user_machine_access(" . $row["member_id"] . ");'>Access</a></td></tr>";
	}
}

$contents = '<table class="userTable" id="register_table">
			<thead>
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Phone</th>
					<th>Tag ID</th>
					<th>Admin</th>
					<th></th>
					<th></th>
				</tr>
			</thead>
			<tbody>' . $table_rows . '
			</tbody>
		</table>';

echo json_encode($contents);
$db->close();
?>
