<?php
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

$varMemberId = $_GET['member_id'];
$varLastLogID = $_GET['last_log_id'];

// Zero ouit 
if ($varLastLogID == "")
{	
	$varLastLogID=0;
}

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();
$retVal="";

//Instantiate Shed object
$shed = new Shed($db);

//set page
$shed->assignPage('tag');

//get tag id from util table
$sql = "select machine_wwn from machine_log where member_id = " . $varMemberId . " and log_id > " . $varLastLogID . " order by log_id desc limit 1";

//execute statement
$stmt = $db->query($sql);

if ( $stmt->num_rows > 0 )
{
	$row = $stmt->fetch_assoc();
	$retVal = $row['machine_wwn'];
}

$contents =  '<form id="machine_wwn_form">
                                <div class="form-group">
					<table>
					  <tr>
					    <td align="right">
                                        <label for="machine_wwn_readout">Machine_WWN:</label>
					</td>
					<td align="left">
                                        <input type="text" id="machine_wwn_readout" name="machine_wwn_readout" value="' . $retVal . '" readonly><br>
					</td>
					<td>
					</td>
					</table>
                                </div>
                                <div class="form-buttons">
                                        <a class="button" href="admin.php">Cancel</a> <a class="button" href="javascript:copyWWN();">Copy WWN</a>
                                </div>
                        </form>
                        
                        <script>
                        function copyWWN(){
                                let tagInput = document.getElementById("machine_wwn_readout");
                                
                                navigator.clipboard.writeText(tagInput.value);
                                console.log("Machine WWN " + tagInput.value + " copied to clipboard");
                        };
                        </script>';

// echo $row['machine_wwn'];
echo json_encode($contents);
$db->close();

	// Get last machine entry for userid and find wwn
  //  $carName = $_GET['foo'];
   // $carBrand = $_GET['bar'];
//    $contents = '<p>Scanned OK member_id=' . $varMemberId . ', last_log_id =' . $varLastLogID . '.</p>';
    // $contents = '<p>Scanned OK' . $carName . ',bar=' . $carBrand . '</p>';
 //   echo json_encode($contents);
?>
