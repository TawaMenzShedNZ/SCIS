<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//get parameters
$first_name = htmlspecialchars($_GET["first_name"]);
$last_name = htmlspecialchars($_GET["last_name"]);
$email = htmlspecialchars($_GET["email"]);
$phone = htmlspecialchars($_GET["phone"]);
$admin = htmlspecialchars($_GET["admin"]);
$tag_id = htmlspecialchars($_GET["tag_id"]);

//update user details
$res = $shed->addUser($first_name, $last_name, $email, $phone, $admin, $tag_id);

session_start();

// Store data in session variables
$_SESSION["source"] = "add_user";
$_SESSION["result"] = $res;

// Redirect user to admin page
header("location: admin.php");
?>
