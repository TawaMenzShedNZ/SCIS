<?php
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

$sql = "select b.first_name
	, b.last_name
	, date(a.signin_date_time) as date
	, time(a.signin_date_time) as signin_time
	, time(a.signout_date_time) as signout_time 
	, timediff(a.signout_date_time, a.signin_date_time) as length
	from sign_in_register a left join member b on a.member_id = b.member_id
	order by date(a.signin_date_time) desc";

//execute sql statement	
$stmt = $db->query($sql);

// Excel file name for download 
$fileName = "signin-data_" . date('Y-m-d') . ".xls"; 

$fields = array('FIRST NAME', 'LAST NAME', 'Date', 'Sign In Time', 'Sign Out Time', 'Length'); 
 
// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n";

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$lineData = array($row['first_name'], $row['last_name'], $row['date'], $row['signin_time'], $row['signout_time'], $row['length']);
		$excelData .= implode("\t", array_values($lineData)) . "\n";
	}
}

header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=$fileName"); 

echo $excelData;
$db->close();



//redirect back to admin
//header("location: admin.php");

?>