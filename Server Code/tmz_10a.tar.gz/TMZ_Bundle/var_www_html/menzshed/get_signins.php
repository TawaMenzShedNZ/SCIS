<?php

include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//get parameters
$param = htmlspecialchars($_GET["type"]);

if (empty($param)){
	//get todays sign ins

	$sql = "SELECT concat(b.first_name, ' ', b.last_name) as name
		, a.signin_date_time
		, a.signout_date_time
	FROM sign_in_register a
	left join member b on a.member_id = b.member_id
	where a.signin_date_time >= '" . date('Y-m-d') . "'
	order by a.signin_date_time desc";
}
else{
	//get all sign ins
	$sql = "SELECT concat(b.first_name, ' ', b.last_name) as name
		, a.signin_date_time
		, a.signout_date_time
	FROM sign_in_register a
	left join member b on a.member_id = b.member_id
	order by a.signin_date_time desc";
}

$stmt = $db->query($sql);

$table_rows='';

if ($stmt->num_rows>0){
	while($row = $stmt->fetch_assoc()){
		$table_rows = $table_rows . "<tr><td>" . $row["name"] . "</td><td>" . $row["signin_date_time"] . "</td><td>" . $row["signout_date_time"] . "</td></tr>";
	}
}

$contents = '<table class="blueTable" id="register_table">
			<thead>
				<tr>
					<th>Name</th>
					<th>Sign In Time</th>
					<th>Sign Out Time</th>
				</tr>
			</thead>
			<tbody>' . $table_rows . '
			</tbody>
		</table>';

echo json_encode($contents);
$db->close();
?>