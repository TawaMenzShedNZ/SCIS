<?php

// FInd out if WWMN already used for machine other than this one
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

$varMachineID = $_GET['machine_id'];
$varMachineWWN = $_GET['machine_wwn'];

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);
error_log("Made into test_mod_wwn");
error_log("varMachinwWWN = " . $varMachineWWN);
error_log("varMachineID = " . $varMachineID);

//set page
$shed->assignPage('tag');

if ($varMachineWWN == NULL)
{
	echo 0;
} else
{
//get tag id from util table
	$sql = "select * from machine where machine_wwn = '" . $varMachineWWN . "' and machine_id NOT LIKE '" . $varMachineID . "'";

//execute statement
	$stmt = $db->query($sql);

	// get count
	$rowcnt = $stmt->num_rows;
	echo $rowcnt;
}
// $log_id = $row['log_id'];
// if ($log_id == NULL)
// { // set to zero
// $log_id=0;
// }
// echo $row['log_id'];
// if ( $varMachineWWN == '111' )
// { echo "1"; 
// } else {
// echo "0";
// }

$db->close();
?>
