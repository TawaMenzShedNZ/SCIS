<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

$member_id = htmlspecialchars($_POST["member_id"]);
echo $member_id."/n";

//remove all access to user
$shed->delAccessMember($member_id);

//Now apply access to those selected
//get parameters
if(is_array($_POST['access'])){
	foreach($_POST['access'] as $m_id  => $value){
		
		echo $value.',';
		$shed->addAccessMachine($value, $member_id);		
	}
}
$res=1;
session_start();

// Store data in session variables
$_SESSION["source"] = "user_access";
$_SESSION["result"] = $res;

// Redirect user to admin page
header("location: admin.php");
?>
