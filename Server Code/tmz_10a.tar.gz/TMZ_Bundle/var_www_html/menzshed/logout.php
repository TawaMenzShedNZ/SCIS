<?php
include_once 'api/class/Database.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

// Initialize the session
session_start();
 
// Unset all of the session variables
$_SESSION = array();
 
// Destroy the session.
session_destroy();

//reset tag_id value
$sql = "UPDATE util SET tag_id =''";

//execute statement
$stmt = $db->query($sql);
 
// Redirect to login page
header("location: index.php");
exit;
?>