<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//get parameters
$mach_name = htmlspecialchars($_GET["mach_name"]);
$description = htmlspecialchars($_GET["description"]);
$machine_wwn = htmlspecialchars($_GET["machine_wwn"]);

//update user details
$res = $shed->addMach($mach_name, $description, $machine_wwn);

session_start();

// Store data in session variables
$_SESSION["source"] = "add_mach";
$_SESSION["result"] = $res;

// Redirect user to admin page
header("location: admin.php");
?>
