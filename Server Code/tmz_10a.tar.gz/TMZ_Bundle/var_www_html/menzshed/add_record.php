//NOT IN USE

<?php
include_once 'api/class/Database.php';

// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: admin.php");
    exit;
}

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//get parameters
$source = $_POST["source"];
$input1 = $_POST["input1"];
$input2 = $_POST["input2"];

$sql = '';

//add access 
if($source == "mach_access"){
	$sql = "insert into member_machine(member_id, machine_id)
	values($input2, $input1)";
	
	//need to check response and check for duplicates
}
//add machine
else if($source == "add_mach"){
	$sql = "insert into machine(name, description)
	values($input1, $input2)";
}
//add user



//execute query
$stmt = $db->query($sql);
echo "error=".$db->error;

if(!empty($db->error)){
	//Duplicated record tried to be added
	if(preg_match('/\bDuplicate\b/',$db->error)){
		$result=0;
	}
	else{
		$result=-1;
	}
}
else {
	$result = 1;
}

//echo "/n result=".$result;

header('Location: admin.php?source='.$source.'&result='.$result);
exit;
?>
<html>

</html>