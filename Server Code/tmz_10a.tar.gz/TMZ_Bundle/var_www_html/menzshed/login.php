<?php
// Initialize the session
session_start();

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//set page
$shed->assignPage('login');

// Check if the user is already logged in, if yes then redirect them to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: admin.php");
    exit;
}
 
// Define variables and initialize with empty values
$password = "";
$password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter admin password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($password_err)){
        //check if the password is correct        
		$result = $shed->adminLogin($password, 'P');

		
		if ($result){
			//password correct
			echo "Correct password";
			// Password is correct, so start a new session
			session_start();
			
			// Store data in session variables
			$_SESSION["loggedin"] = true;
			
			// Redirect user to welcome page
			header("location: admin.php");
		}
		else{
			// Password is not valid, display a generic error message
			$login_err = "Invalid password.".$result;
		}

	}
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/index.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body style="background-color:#71b8ca!important;">
	<div class="logo">
		<img src="images/Logo.jpg" class="logo">
	</div>
	<div class="welcome-wrap">
		<div class="welcome-content">
			<h1>Admin</h1>
		</div>
	</div>
	<div class="spacer">
	<p> </P>
	</div>
    <div class="form-wrapper" style="display:flex">
		<div class="form-content">
			<h2>Manual Login</h2>
			<p>Please enter the admin password to login.</p>
			<?php 
			//show error message if password incorrect
			if(!empty($login_err)){
				echo '<div class="alert alert-danger">' . $login_err . '</div>';
			}        
			?>

			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
					<span class="invalid-feedback"><?php echo $password_err; ?></span>
				</div>
				<div class="form-buttons">
					<input type="submit" class="button" value="Login">
				</div>
			</form>
		</div>
    </div>
</body>
</html>
