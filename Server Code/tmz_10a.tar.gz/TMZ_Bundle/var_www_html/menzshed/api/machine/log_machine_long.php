<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');
	
	include_once '../class/Database.php';
	include_once '../class/Shed.php'; 
	//Instantiate DB & Connect
	$database = new Database();
	$db = $database->connect();
	
	//Instantiate Shed object
	$shed = new Shed($db);
	
	//get parameters
	$tag_id = htmlspecialchars($_GET["tag"]);
	$machine_wwn_id = htmlspecialchars($_GET["machine_wwn"]);
	
	//get member id
	$member_id = $shed->get_member_id($tag_id);
	// 
	$machine_id = $shed->get_machine_id($machine_wwn_id);
	
	//add record to machine log table
	$shed->logMachineWWN($machine_id, $machine_wwn_id, $member_id);
//	$shed->logMachine($machine_id, $member_id);
	echo '1';
?>
