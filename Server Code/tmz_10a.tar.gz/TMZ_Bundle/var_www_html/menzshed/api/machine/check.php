<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');
	
	include_once '../class/Database.php';
	include_once '../class/Shed.php';
	
	//Instantiate DB & Connect
	$database = new Database();
	$db = $database->connect();
	
	//Instantiate Shed object
	$shed = new Shed($db);
	
	//get parameters
	$tag_id = htmlspecialchars($_GET["tag"]);
	$machine_id = htmlspecialchars($_GET["machine"]);
	
	//get member id
	$member_id = $shed->get_member_id($tag_id);
	
	//$temp = ['member' => $member_id, 'machine' => $machine_id];
	//echo json_encode($temp);
        trigger_error("check - made ubti user:", E_USER_WARNING);

	// Check for machine id	
	if (empty($machine_id)){
		$machine_id=0;
	}
	if (!$member_id==0){
		//check if member has signed in already
		$signed_result = $shed->signed_status($member_id);
		if ($signed_result==1){
			
			//check member can use machine
			$result = $shed->auth_user_machine($member_id, $machine_id);
			
			if($result){
				if($result->num_rows > 0){
					//member has access
					$data = 1;
				}
				else{
					//member does not have access
                                        trigger_error("check - no machine access", E_USER_WARNING);
                                        $rtn=$shed->logErrorMessage($member_id,$machine_id,"","ERROR", "No Machine Access");
					$data = 0;
				}
			}
			else{
				echo "Error in ".$query."<br>".$db->error;
                                trigger_error("check - no machine access", E_USER_WARNING);
                                $rtn=$shed->logErrorMessage($member_id,$machine_id,"","ERROR", "Internal error machine");
				$data = 0;
			}
		}
		else{
			// not signed in
                        trigger_error("check - user not signed in", E_USER_WARNING);
                        $rtn=$shed->logErrorMessage($member_id,$machine_id,"","ERROR", "User not signed in");
			$data = 0;
		}
	}
	else{
		// card unknown
                $rtn=$shed->logErrorMessage($member_id,$machine_id,"","ERROR", "Invalid User Fob");
                trigger_error("check - invalid user " . $rtn . ":", E_USER_WARNING);
		$data = 0;
	}
	//send result
	echo $data;
?>
