<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');
	
	include_once '../class/Database.php';
	include_once '../class/Shed.php';
	
	//Instantiate DB & Connect
	$database = new Database();
	$db = $database->connect();
	
	//Instantiate Shed object
	$shed = new Shed($db);
	
	//get parameters
	$tag_id = htmlspecialchars($_GET["tag"]);
	$machine_wwn = htmlspecialchars($_GET["machine_wwn"]);

	// First resolve User, then get WWN for user
	$member_id = $shed->get_member_id($tag_id);
	if (empty($member_id)){
		// Invalid user - record event
		$data=0;
		$rtn=$shed->logErrorMessage(0,0,$machine_wwn,"ERROR", "Invalid User Fob");
		trigger_error("check_long - invalid user " . $rtn . ":", E_USER_WARNING);
	} else {
		// Resolve wwn to machine
        	$machine_id = $shed->get_machine_id($machine_wwn);
		if ( empty($machine_id) ) {
			// machine id not matched - record with tag id on log
			$data=0;
			$rtn=$shed->logErrorMessage($member_id,0,$machine_wwn,"ERROR", "Invalid WWN " . $machine_wwn);
			trigger_error("check_long - invalid machine wwn", E_USER_WARNING);
		} else {
			//check if member has signed in already
			$signed_result = $shed->signed_status($member_id);
			if ($signed_result==1){
			
				//check member can use machine
				$result = $shed->auth_user_machine($member_id, $machine_id);
			
				if($result){
					if($result->num_rows > 0){
						//member has access
						$data = 1;
					}
					else{
						//member does not have access
						$data = 0;
						trigger_error("check_long - no machine access", E_USER_WARNING);
						$rtn=$shed->logErrorMessage($member_id,$machine_id,$machine_wwn,"ERROR", "No Machine Access");
					}
				}
				else{
					echo "Error in ".$query."<br>".$db->error;
				}
			}
			else{
				// User not signed in
				$data = 0;
				trigger_error("check_long - user not signed in", E_USER_WARNING);
				$rtn=$shed->logErrorMessage($member_id,$machine_id,$machine_wwn,"ERROR", "User not signed in");
			}
		}
	}
	//send result
	trigger_error("check_long - return data " . $data . ".", E_USER_WARNING);
	echo $data;
?>
