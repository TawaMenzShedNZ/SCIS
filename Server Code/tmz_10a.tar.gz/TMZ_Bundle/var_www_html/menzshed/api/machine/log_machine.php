<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');
	
	include_once '../class/Database.php';
	include_once '../class/Shed.php';
	
	//Instantiate DB & Connect
	$database = new Database();
	$db = $database->connect();
	
	//Instantiate Shed object
	$shed = new Shed($db);
	
	//get parameters
	$tag_id = htmlspecialchars($_GET["tag"]);
	$machine_id = htmlspecialchars($_GET["machine"]);
	
	//get member id
	$member_id = $shed->get_member_id($tag_id);
		
	//add record to machine log table
	$shed->logMachine($machine_id, $member_id);
	echo '1';
?>