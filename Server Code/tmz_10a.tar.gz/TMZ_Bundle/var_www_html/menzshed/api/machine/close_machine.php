<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');
	
	include_once '../class/Database.php';
	include_once '../class/Shed.php';
	
	//Instantiate DB & Connect
	$database = new Database();
	$db = $database->connect();
	
	//Instantiate Shed object
	$shed = new Shed($db);
	
	//get parameters
	$machine_id = htmlspecialchars($_GET["machine"]);
	
	//Close off any machine log record
	$shed->logoutMachine($machine_id);

	echo '1';
?>
