<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	//header('Content-Type: application/json');
	
	include_once '../class/Database.php';
	include_once '../class/Shed.php';
	
	//Instantiate DB & Connect
	$database = new Database();
	$db = $database->connect();
	
	//Instantiate Shed object
	$shed = new Shed($db);
	
	//get parameters
	$tag_id = htmlspecialchars($_GET["tag"]);
	
	//get member id
	$member_id = $shed->get_member_id($tag_id);
	
	//get current page user on is_a
	$page = $shed->getPage();
	
	//reset password in util table
	$shed->resetAccess();
	$result=0;
	
	if ($page == 'index'){
		if (is_null($member_id)){
			//tag id not on database
			$result = 9;
		}
		else{//member exists
			//attempt to register member
			$result = $shed->register($member_id);
			//echo "i:" . $result;
		}
	}
	else if ($page == 'login'){
		//check user can access admin section
		$ans = $shed->adminLogin($member_id, 'T');
		//echo "l" . $result;
		if($ans){
				$result=0; //successful
		}
		else{
			$result=1;
		}
	}
	else if ($page == 'tag'){
		//add tag id to util table to picked up by user
		$shed->scanTag($tag_id);
		$result = 0;
	}
	else if($page='admin'){
		//will send tag id to add member form
		
	}
	echo $result;
?>