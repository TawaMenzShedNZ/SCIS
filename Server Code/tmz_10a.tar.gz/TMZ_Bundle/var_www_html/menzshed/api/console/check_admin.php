<?php

include_once '../class/Database.php';
include_once '../class/Shed.php';


//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();
//Instantiate Shed object
$shed = new Shed($db);
 
//check admin access column in util table to see if the user is allowed to access the admin section
	$access = $shed->getAdminAccess();

	if ($access){
		//Start a new session
		session_start();
		
		// Store data in session variables
		$_SESSION["loggedin"] = true;
	}
	echo json_encode($access);
$db->close();
?>