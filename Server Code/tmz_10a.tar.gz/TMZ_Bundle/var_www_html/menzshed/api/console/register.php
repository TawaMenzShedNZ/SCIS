<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	//header('Content-Type: application/json');
	
	include_once '../class/Database.php';
	include_once '../class/Shed.php';
	
	//Instantiate DB & Connect
	$database = new Database();
	$db = $database->connect();
	
	//Instantiate Shed object
	$shed = new Shed($db);
	
	//get parameters
	$tag_id = htmlspecialchars($_GET["tag"]);
	
	//get member id
	$member_id = $shed->get_member_id($tag_id);
	
	//register member or not
	$result = $shed->register($member_id);
	
?>