<?php
	class Shed{
		//DB properties
		private $conn;
		
		//Constructor
		public function __construct($db){
			$this->conn = $db;
		}
		
		//Get a members Id from their tag ID
		public function get_member_id($tag_uid){
			$result=null;
			
			$sql = "select member_id from member where tag_id = '" . $tag_uid . "'";
			
			//execute the statement
			$stmt = $this->conn->query($sql);
			
			//fetch record value
			if ($stmt->num_rows > 0){
				while($row = $stmt->fetch_assoc()){
					$result = $row["member_id"];
				}
			}
			else {
				// return userid of zero
				return 0;
			}
			
			return $result;
		}
		
		//Get a machine Id from their WWN
		public function get_machine_id($machine_wwn){
			$result=null;
			
			$sql = "select machine_id from machine where machine_wwn = '" . $machine_wwn . "'";
			
			//execute the statement
			$stmt = $this->conn->query($sql);
			
			//fetch record value
			if ($stmt->num_rows > 0){
				while($row = $stmt->fetch_assoc()){
					$result = $row["machine_id"];
				}
			}
			
			return $result;
		}
		
		//authenticate user machine
		public function auth_user_machine($in_mem_id, $in_mac_id){
			$sql = 'select *
			from member_machine
			where member_id = ' . $in_mem_id . ' and machine_id = ' . $in_mac_id . '
			order by id';

			//execute the statement
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		//sign member in or out
		public function register($in_mem_id){
			
			//establish if member has already signed in or not
			$result = $this->signed_status($in_mem_id);
			$update = null;
			//echo "signed status: " . $result;
			
			if ($result == 1){
				//already signed in so sign out
				//echo "\nsigning out...";
				$update = $this->sign_out($in_mem_id);
				//echo "\b" . $update;
			}
			else {
				//already sign out so sign in
				//echo "\nsigning in...";
				$update = $this->sign_in($in_mem_id);
			}
			
			return $result;
		}
		
		//sign member in
		public function sign_in($in_mem_id){
			//add record to sign_in_register
			$sql = "INSERT INTO sign_in_register (member_id)
			VALUES (" . $in_mem_id . " )";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		//sign member out
		public function sign_out($in_mem_id){
			//add record to sign_in_register
			$sql = "UPDATE sign_in_register
			SET signout_date_time = current_timestamp()
			WHERE member_id = " . $in_mem_id . " and date(signin_date_time) = current_date() and signout_date_time IS NULL";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		//return whether or not a member has signed in
		public function signed_status($in_member_id){

			//has the member signed in today
			$sql = "select * from sign_in_register where member_id =" . $in_member_id . " and signin_date_time >= '" . date("Y-m-d") . "' and signout_date_time IS NULL";
			
			//execute query
			$stmt = $this->conn->query($sql);

			//if there are records, establish last type
			if ($stmt->num_rows > 0){
				return 1; //returns 1 if signed in, 0 if signed out
			}
			//no records = not signed in
			else {
				return 0;
			}
		}
		
		//log in to the admin section
		public function adminLogin($password, $type){
			$result = null;
			
			//Password entered
			if ($type == 'P'){
				// Prepare a select statement to grab password from member table
				$sql = "SELECT tag_id FROM member WHERE first_name = 'admin'";
				
				//execute query
				$stmt = $this->conn->query($sql);
				
				if ($stmt->num_rows>0){
					while($row = $stmt->fetch_assoc()){
						$result = $row["tag_id"];
					}
				}
				if ($result == $password){
					//password correct
					return true;
				}
				else {
					return false;
				}
			}
			//Tag entered
			else if ($type == 'T'){
				$sql = "SELECT admin FROM member WHERE member_id = '" . $password . "'";
					
				$stmt = $this->conn->query($sql);
					
				if ($stmt->num_rows>0){
					while($row = $stmt->fetch_assoc()){
						$result = $row["admin"];
					}
				}
				if ($result == 'Y'){
					//tag has admin access
					//update util password column
					$this->setAdminAccess();
					return true;
				}
				else {
					return false;
				}
			}
			
			$stmt->close();
		}
		
		//Add or update machine log record
		public function logMachine($machine_id, $mem_id){
			$sql = "select * from machine_log where machine_id = " . $machine_id . " and log_in_time >= '" . date("Y-m-d") . "' and log_out_time IS NULL";
			
			//execute query
			$stmt = $this->conn->query($sql);

			//if there are records then machine needs to be logged out
			if ($stmt->num_rows > 0){
				//log machine out
				$res = $this->logoutMachine($machine_id);
			}
			//no records = not signed in
			else {
				//log machine in
				$res = $this->loginMachine($machine_id, $mem_id);
			}
			return true;
		}
		
		//Add or update machine log record
		public function logMachineWWN($machine_id, $machine_wwn, $mem_id){
			// Get machine id from WWN
			$rtn_machine_id="";
			$sql_id = "select machine_id from machine where machine_wwn = '" . $machine_wwn . "'";
			$stmt1 = $this->conn->query($sql_id);
			if ($stmt1->num_rows > 0){
				while($row = $stmt1->fetch_assoc()){
					$rtn_machine_id = $row["machine_id"];
				}
			}
			if ($rtn_machine_id == NULL){
				//no entry, return false
				return false;
			}

			// Check if needs to be logged out
			$sql = "select * from machine_log where machine_id = " . $rtn_machine_id . " and log_in_time >= '" . date("Y-m-d") . "' and log_out_time IS NULL";
			
			//execute query
			$stmt = $this->conn->query($sql);

			//if there are records then machine needs to be logged out
			if ($stmt->num_rows > 0){
				//log machine out
				$res = $this->logoutMachineWWN($machine_wwn);
			}
			//no records = not signed in
			else {
				//log machine in
				$res = $this->loginMachineWWN($machine_id, $machine_wwn, $mem_id);
			}
			return true;
		}
		
		// add a log in record for a machine
		private function loginMachine($machine_id, $mem_id){
			// Prepare a insert statement
			$sql = "INSERT INTO machine_log (member_id, machine_id, log_status)
			VALUES (" . $mem_id . "," . $machine_id . ", 'OK' )";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		// add a log in record for a machine
		private function loginMachineWWN($machine_id, $machine_wwn, $mem_id){
			// Get machine id from WWN
                        $str_machine_wwn = "$machine_wwn";
			$sql_id = "select machine_id from machine where machine_wwn = '" . $machine_wwn . "'";
			$stmt1 = $this->conn->query($sql_id);
			if ($stmt1->num_rows > 0){
				while($row = $stmt1->fetch_assoc()){
					$rtn_machine_id = $row["machine_id"];
				}
			}
			if ($rtn_machine_id == NULL) {
				//no entry, return false
				return false;
			}

			// Prepare a insert statement
			$sql = "INSERT INTO machine_log (member_id, machine_id, machine_wwn, log_status)
			VALUES (" . $mem_id . "," . $rtn_machine_id . ",'" . $str_machine_wwn . "', 'OK' )";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		//log out machine
		public function logoutMachine($machine_id){
			// Prepare a update statement
			$sql = "UPDATE machine_log
			SET log_out_time = current_timestamp()
			WHERE machine_id=" . $machine_id . " and date(log_in_time) = current_date() and log_out_time IS NULL";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		//log out machine
		public function logoutMachineWWN($machine_wwn){

			// Get machine id from WWN
			$rtn_machine_id="";
			$sql_id = "select machine_id from machine where machine_wwn = '" . $machine_wwn . "'";
			$stmt1 = $this->conn->query($sql_id);
			if ($stmt1->num_rows > 0){
				while($row = $stmt1->fetch_assoc()){
					$rtn_machine_id = $row["machine_id"];
				}
			}
			if ($rtn_machine_id == NULL){
				return false;
			}

			// Prepare a update statement
			$sql = "UPDATE machine_log
			SET log_out_time = current_timestamp()
			WHERE machine_id=" . $rtn_machine_id . " and date(log_in_time) = current_date() and log_out_time IS NULL";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		// log error message AAAA
		public function logErrorMessage($member_id, $machine_id, $machine_wwn, $log_status, $log_reason){
			// Prepare a update statement
			$sql = "INSERT INTO machine_log (member_id, machine_id, machine_wwn, log_out_time, log_status, log_reason)
			VALUES (" . $member_id . "," . $machine_id . ",'" . $machine_wwn . "',current_timestamp() ,'" . $log_status . "','" . $log_reason . "')";
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		//set the page the user is viewing
		public function assignPage($page_name){
			// Prepare a update statement
			$sql = "UPDATE util
			SET page = '" . $page_name . "'";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		//get page the user is viewing
		public function getPage(){
			$sql = "select page from util";
			
			//execute query
			$stmt = $this->conn->query($sql);
			
			if ($stmt->num_rows>0){
				while($row = $stmt->fetch_assoc()){
					$result = $row["page"];
				}
			}
			//default set to index page
			else $result = 'index';
			
			return $result;
			
			$stmt->close();
		}
		
		//reset admin access on util table
		public function resetAccess(){
			$sql = "update util SET admin_access = 'n'";
			
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		//get admin access value
		public function getAdminAccess(){
			$sql = "select admin_access from util";
			$stmt = $this->conn->query($sql);
			
			if ($stmt->num_rows>0){
				while($row = $stmt->fetch_assoc()){
					//if value is y then ok to access admin section
					if ($row["admin_access"] == 'y'){
						$result = true;
					}
					else $result = false;
				}
			}
			//default return value is flase
			else $result = false;

			return $result;
		}
		
		//set admin access
		public function setAdminAccess(){
			$sql = "update util SET admin_access = 'y'";
			
			$stmt = $this->conn->query($sql);
			
			return true;
		}
		
		//Add a user
		public function addUser($first_name, $surname, $email, $phone, $admin, $tag_id){
			
			//delete from member_machine
			$sql = "insert into member (first_name, last_name, email, phone, tag_id, admin) values ('" . $first_name . "','".$surname."','".$email."','".$phone."','".$tag_id."','".$admin."')";
			
			$stmt = $this->conn->query($sql);
			return $stmt;
		}
		
		//update user details
		public function updateUser($member_id, $first_name, $surname, $email, $phone, $tag_id, $admin){
			$sql='update member 
				set first_name = "'. $first_name .'", last_name = "'. $surname .'", email = "'. $email .'", phone = "'. $phone .'", tag_id = "'.$tag_id.'", admin = "'. $admin .'"
				where member_id = '. $member_id;

			//echo $sql;
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		public function delUser($member_id){
			//delete from member_machine
			$sql = 'delete from member_machine where member_id = ' . $member_id;
			
			$stmt = $this->conn->query($sql);
			
			//delete from user table 
			$sql = 'delete from member where member_id = ' . $member_id;
			
			$stmt = $this->conn->query($sql);
			
			return true;
		}
		
		
		//Machine functions
		//Add a machine
		public function addMach($name, $description, $machine_wwn){
			
			//delete from member_machine
			$sql = "insert into machine (name, description, machine_wwn) values ('" . $name . "','".$description."','" . $machine_wwn . "')";
			
			$stmt = $this->conn->query($sql);
			return $stmt;
		}
		
		//update user details
		public function updateMach($machine_id, $name, $description, $machine_wwn){
			$sql='update machine 
				set name = "'. $name .'", description = "'. $description .'", machine_wwn = "' . $machine_wwn . '"
				where machine_id = '. $machine_id;

			//echo $sql;
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		public function delMach($machine_id){
			//delete from member_machine
			$sql = 'delete from member_machine where machine_id = ' . $machine_id;
			
			$stmt = $this->conn->query($sql);
			
			//delete from machine table 
			$sql = 'delete from machine where machine_id = ' . $machine_id;
			
			$stmt = $this->conn->query($sql);
			
			return true;
		}
		
		//add access to a machine for a member
		public function addAccessMachine($machine_id, $member_id){
			$sql = "INSERT INTO member_machine(member_id, machine_id) VALUES('" . $member_id . "','" . $machine_id . "')";
			$stmt = $this->conn->query($sql);
		}
		public function delAccessMachine($machine_id){
			//delete 
			$sql = "DELETE FROM member_machine where Machine_id = ".$machine_id;
			$stmt = $this->conn->query($sql);
		}
		public function delAccessMember($member_id){
			//delete 
			$sql = "DELETE FROM member_machine where member_id = ".$member_id;
			$stmt = $this->conn->query($sql);
		}
		
		//add tag id to util table
		public function scanTag($tag_id){
			$sql = 'update util SET tag_id = "'. $tag_id . '"';
			
			$stmt = $this->conn->query($sql);
		}
		//clear tag id
		public function clearTag(){
			$sql = 'update util SET tag_id = ""';
			$stmt = $this->conn->query($sql);
		}
		
		//Report functions
		public function get_day_summary(){
			$sql = 'select distinct dayname(a.sign_in_date) as day
				, sign_in_date
				, count(attend) as num_attendees
				from (
					SELECT 1 as attend
					, date(a.signin_date_time) as sign_in_Date
					FROM sign_in_register a
				) a
				group by sign_in_date
				order by sign_in_date desc';
				
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
		
		public function get_avg_summary(){
			//calculate the average attendance for each day (Sunday, Tuesday, Thursday, Saturday)
			$sql = 'select distinct b.day
					, round(AVG(b.num_attendees),2) as avg_attend
				from (
					select distinct dayname(a.sign_in_date) as day
					, sign_in_date
					, count(attend) as num_attendees
					from (
						SELECT 1 as attend
						, date(a.signin_date_time) as sign_in_Date
						FROM sign_in_register a
						where dayofweek(a.signin_date_time) in (1,3,5,7)
					) a
					group by sign_in_date
					order by dayofweek(a.sign_in_date)
				 )b group by b.day';
				 
			$stmt = $this->conn->query($sql);
			
			return $stmt;
		}
	}
?>
