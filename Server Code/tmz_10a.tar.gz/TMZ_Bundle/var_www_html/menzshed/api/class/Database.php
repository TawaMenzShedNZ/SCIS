<?php
	class Database {
		private $servername = 'localhost';
		private $user = 'menzshed_user';
		private $password = 'password'; //To be completed if you have set a password to root
		private $database = 'menzshed'; //To be completed to connect to a database. The database must exist.
		private $port = NULL; //Default must be NULL to use default port
		private $conn;

		//DB Connect
		public function connect(){
			$this->conn = null;
			
			try{
				$this->conn = new mysqli($this->servername, $this->user, $this->password, $this->database, $this->port);
			}catch(mysqli_sql_exception $e){
				die('Connect Error (' . $this->conn->connect_errno . ') '
            . $this->conn->connect_error);
			}
			
			return $this->conn;
		}
		
		//DB Disconnect
		public function disconnect(){
			$this->conn->close();
		}

	}
?>
