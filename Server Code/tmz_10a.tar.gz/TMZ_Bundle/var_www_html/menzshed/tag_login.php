<?php
include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

//set page
$shed->assignPage('login');

//reset 
$shed->resetAccess();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/index.css">
	<script src="js/jquery.min.js"></script>
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
	<script>

		// refresh every 1 second
		var refresher = setInterval(function() {
		  $.ajax({
				url: 'api/console/check_admin.php',
				type: "POST",
				success: function (response) {
					/*$('#res').html(response);*/
				   if (response == "true") {
						window.location = "admin.php";
					}
				}
				});
		}, 1000);
	</script>
</head>
<body style="background-color:#71b8ca!important;">
	<div class="logo">
		<img src="images/Logo.jpg" class="logo">
	</div>
	<div class="welcome-wrap">
		<div class="welcome-content">
			<h1>Admin Login</h1>
		</div>
	</div>
	<div class="sticky-menu" id="menu">
		<p><a class="button" href="index.php">Home</a></p>
	</div>
	<div class="spacer">
	<p> </P>
	</div>
    <div class="form-wrapper" style="display:block;">
		<div class="form-content" style="display:block;">
			<h2>Login</h2>
			<p>Please scan your Menzshed tag to login.</p>
			<p>Note: you will need to have admin access to enter the Admin area</p>

			<p> Click <a href="login.php">here</a> to log in with a password</p>
			
			<p id="res"> </p>
		</div>
    </div>
</body>
</html>
