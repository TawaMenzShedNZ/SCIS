<?php

include_once 'api/class/Database.php';
include_once 'api/class/Shed.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Instantiate Shed object
$shed = new Shed($db);

$machine_id = htmlspecialchars($_POST["machine_id"]);
echo $machine_id."/n";

//remove all access to machine
$shed->delAccessMachine($machine_id);

//Now apply access to those selected
//get parameters
if(is_array($_POST['access'])){
	foreach($_POST['access'] as $m_id  => $value){
		
		echo $value.',';
		$shed->addAccessMachine($machine_id, $value);		
	}
}
$res=1;
session_start();

// Store data in session variables
$_SESSION["source"] = "mach_access";
$_SESSION["result"] = $res;

// Redirect user to admin page
header("location: admin.php");
?>
