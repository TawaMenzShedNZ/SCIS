#!/bin/bash

function enter_parameter_files
{
	# Enter the parameter files
	touch /tmp/scis_upgrade_parms
	export SITENAME=`grep "^SITENAME:" /tmp/scis_upgrade_parms |head -n 1 |awk -F":" '{print $2}'`
	printf " Enter Sitename(%s):"  "${SITENAME}"
	read NEWSITE
	if [[ "${NEWSITE}" == "" ]]
	then
		export NEWSITE="${SITENAME}"
	fi
	grep -v "^SITENAME:" /tmp/scis_upgrade_parms > /tmp/scis_upgrade_parms2
	echo "SITENAME:${NEWSITE}" >> /tmp/scis_upgrade_parms2
	cp /tmp/scis_upgrade_parms2 /tmp/scis_upgrade_parms
	
	export JPEGNAME=`grep "^JPEGNAME:" /tmp/scis_upgrade_parms |head -n 1 |awk -F":" '{print $2}'`
	printf " Enter Site JPEG Name(%s):" "${JPEGNAME}"
	read NEWJPEG
	if [[ "${NEWJPEG}" == "" ]]
	then
		export NEWJPEG="${JPEGNAME}"
	fi
	grep -v "^JPEGNAME:" /tmp/scis_upgrade_parms > /tmp/scis_upgrade_parms2
	echo "JPEGNAME:${NEWJPEG}" >> /tmp/scis_upgrade_parms2
	cp /tmp/scis_upgrade_parms2 /tmp/scis_upgrade_parms

	cat /tmp/scis_upgrade_parms
	read	

}

function upgrade_database
{
	# upgrade database 
	if [[ ! -f ${SRCDIR}/mysql/upgrade_database.sql ]]
	then
		echo "Can't find  ${SRCDIR}/mysql/upgrade_database.sql - return to coninue"
		read
		return
	fi
	mysql -uroot -p${SQLPASS} < ${SRCDIR}/mysql/upgrade_database.sql
	echo
	read
	echo "Return to continue"
}

function backup_files
{
	# create tarball
	if [[ -f ${SRCDIR}/before_tar_${DTG} ]]
	then
		echo "Tarball already exists - move?"
		read ANS
		if [[ "${ANS}" == [Yy] ]]
		then
			export CNT=`ls -A ${SRCDIR}/before_tar_${DTG}* |wc -l`
			mv ${SRCDIR}/before_tar_${DTG} ${SRCDIR}/before_tar_${DTG}_${CNT}
		fi
	fi

	# Create sql dump
	echo "Dumping SQL Data"
	if [[ ! -d ${WORKDIR}/upgrade_sql ]]
	then
		mkdir ${WORKDIR}/upgrade_sql
	fi	
	# mysqldump -u root -p$SQLPASS menzshed > ${WORKDIR}/upgrade_sql/before_dump_${DTG}
	mysqldump -u root -p$SQLPASS --databases menzshed > ${WORKDIR}/upgrade_sql/before_dump_${DTG}
	
	echo "Creating tarball" 
	cd ${WORKDIR}
	if [[ $? == "0" ]]
	then
		tar -czvf ${SRCDIR}/before_tar_${DTG} *
	fi
}

function regen_statistics
{
	# output
	echo "regen statistics"	

	# Loop through files
	cat /dev/null > /tmp/work_file_sum
	export SRCDIR=`pwd`
	for i in $(ls -A ${SRCDIR}/var_www_html/menzshed)
	do
		if [[ ! -d ${SRCDIR}/var_www_html/menzshed/${i} ]]
		then
			export SUM=`sum ${SRCDIR}/var_www_html/menzshed/${i} |awk '{print $1"_"$2}'`
			echo "CURRENT html ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${SRCDIR}/var_www_html/menzshed/api/class)
	do
		if [[ ! -d ${SRCDIR}/var_www_html/menzshed/api/class/${i} ]]
		then
			export SUM=`sum ${SRCDIR}/var_www_html/menzshed/api/class/${i} |awk '{print $1"_"$2}'`
			echo "CURRENT api_class ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${SRCDIR}/var_www_html/menzshed/api/console)
	do
		if [[ ! -d ${SRCDIR}/var_www_html/menzshed/api/console/${i} ]]
		then
			export SUM=`sum ${SRCDIR}/var_www_html/menzshed/api/console/${i} |awk '{print $1"_"$2}'`
			echo "CURRENT api_console ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${SRCDIR}/var_www_html/menzshed/api/machine)
	do
		if [[ ! -d ${SRCDIR}/var_www_html/menzshed/api/machine/${i} ]]
		then
			export SUM=`sum ${SRCDIR}/var_www_html/menzshed/api/machine/${i} |awk '{print $1"_"$2}'`
			echo "CURRENT api_machine ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${SRCDIR}/var_www_html/menzshed/css)
	do
		if [[ ! -d ${SRCDIR}/var_www_html/menzshed/css/${i} ]]
		then
			export SUM=`sum ${SRCDIR}/var_www_html/menzshed/css/${i} |awk '{print $1"_"$2}'`
			echo "CURRENT css ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	

	# WORKDIR
	for i in $(ls -A ${WORKDIR}/menzshed/)
	do
		if [[ ! -d ${WORKDIR}/menzshed/${i} ]]
		then
			export SUM=`sum ${WORKDIR}/menzshed/${i} |awk '{print $1"_"$2}'`
			echo "TARGET html ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${WORKDIR}/menzshed/api/class)
	do
		if [[ ! -d ${WORKDIR}/menzshed/api/class/${i} ]]
		then
			export SUM=`sum ${WORKDIR}/menzshed/api/class/${i} |awk '{print $1"_"$2}'`
			echo "TARGET api_class ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${WORKDIR}/menzshed/api/console)
	do
		if [[ ! -d ${WORKDIR}/menzshed/api/console/${i} ]]
		then
			export SUM=`sum ${WORKDIR}/menzshed/api/console/${i} |awk '{print $1"_"$2}'`
			echo "TARGET api_console ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${WORKDIR}/menzshed/api/machine)
	do
		if [[ ! -d ${WORKDIR}/menzshed/api/machine/${i} ]]
		then
			export SUM=`sum ${WORKDIR}/menzshed/api/machine/${i} |awk '{print $1"_"$2}'`
			echo "TARGET api_machine ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	for i in $(ls -A ${WORKDIR}/menzshed/css)
	do
		if [[ ! -d ${WORKDIR}/menzshed/css/${i} ]]
		then
			export SUM=`sum ${WORKDIR}/menzshed/css/${i} |awk '{print $1"_"$2}'`
			echo "TARGET css ${i} ${SUM}" >> /tmp/work_file_sum
		fi
	done	
	echo "Regen done - return to continue"
	read
}

function display_statistics
{
	echo " LOCATION   | FILENAME         | CURRENT         | TARGET"
	echo " ========     ================   =============     ====="

	for i in html  api_class api_console api_machine css
	do
		# Get list of files
		for j in $(grep " ${i} " /tmp/work_file_sum |awk '{print $3}' |sort -u)
		do
			printf " %-10s | %-20s |" ${i} ${j}
			export WORKVAR=""
			for k in CURRENT TARGET
			do
				export SUM=`grep "${k} ${i} ${j} " /tmp/work_file_sum |head -n 1 |awk '{print $4}'`
				if [[ "${SUM}" == "" ]]
				then
					export SUM="-"
				fi
				printf " %-10s |" ${SUM}

				export WORKVAR="${WORKVAR} ${SUM}"
			done

			# evaluate work var
			export FCNT=`echo "${WORKVAR}" |awk '{print NF}'`
			if (( $FCNT < 2 ))
			then
				printf " Missing\n"
			else
				# Check same
				export P1=`echo "${WORKVAR}" |awk '{print $1}'`	
				export P2=`echo "${WORKVAR}" |awk '{print $2}'`	
				if [[ "${P1}" != "${P2}" ]]
				then
					printf " Mismatch\n"
				else
					printf "\n"
				fi
			fi
		done

	done

	# check database
	echo "use menzshed;" > /tmp/work_mysql_columns1
	echo "describe member;" >> /tmp/work_mysql_columns1
	echo "use menzshed;" > /tmp/work_mysql_columns2
	echo "describe machine;" >> /tmp/work_mysql_columns2
	echo "use menzshed;" > /tmp/work_mysql_columns3
	echo "describe machine_log;" >> /tmp/work_mysql_columns3
	mysql -uroot -p${SQLPASS} < /tmp/work_mysql_columns1 2>&1 |grep -v Warning > /tmp/work_mysql_columns_out1
	mysql -uroot -p${SQLPASS} < /tmp/work_mysql_columns2 2>&1 |grep -v Warning > /tmp/work_mysql_columns_out2
	mysql -uroot -p${SQLPASS} < /tmp/work_mysql_columns3 2>&1 |grep -v Warning > /tmp/work_mysql_columns_out3
	echo
	echo " Table      Column      Present"
	echo " ---------+-----------+------"
	export SRC=member
	for i in technician
	do
		export FNDCNT=`grep ${i} /tmp/work_mysql_columns_out1 |wc -l`
		printf " %-10s | %-10s | %i\n" ${SRC} ${i} ${FNDCNT}
	done
	export SRC=machine
	for i in machine_wwn current_control cutoff_current cutoff_time
	do
		export FNDCNT=`grep ${i} /tmp/work_mysql_columns_out2 |wc -l`
		printf " %-10s | %-10s | %i\n" ${SRC} ${i} ${FNDCNT}
	done
	export SRC=machine_log
	for i in machine_wwn log_status log_reason
	do
		export FNDCNT=`grep ${i} /tmp/work_mysql_columns_out3 |wc -l`
		printf " %-10s | %-10s | %i\n" ${SRC} ${i} ${FNDCNT}
	done

	# SHow zip files
	export ZCNT=`ls -al ${SRCDIR}/before_tar_${DTG}* 2>&1 |grep -v "No such file or directory" |wc -l`
	if [[ ${ZCNT} == "0" ]]
	then
		echo " Zip File: ${SRCDIR}/before_tar_${DTG} - not present"
	else
		echo " Zip File: ${SRCDIR}/before_tar_${DTG} - ${ZCNT} versions"
	fi
}

function upgrade_files
{
	export ID=""
	echo "Upgrading files - copying var/www/html"
	cp ${SRCDIR}/var_www_html/menzshed/* ${WORKDIR}/menzshed	

	echo "Upgrading files - copying var/www/html/api/class"
	cp ${SRCDIR}/var_www_html/menzshed/api/class/* ${WORKDIR}/menzshed/api/class

	echo "Upgrading files - copying var/www/html/api/console"
	cp ${SRCDIR}/var_www_html/menzshed/api/console/* ${WORKDIR}/menzshed/api/console

	echo "Upgrading files - copying var/www/html/api/class"
	cp ${SRCDIR}/var_www_html/menzshed/api/machine/* ${WORKDIR}/menzshed/api/machine

	echo "Upgrading files - copying var/www/html/css"
	cp ${SRCDIR}/var_www_html/menzshed/css/* ${WORKDIR}/menzshed/css

	regen_statistics
	echo "Return to continue"
	read
}

# Setup files
touch /tmp/work_file_sum
touch /tmp/cred_upgrade

export DTG=`date '+%Y%m%d'`
export OPTION=""
echo "Enter password for mysql:"
read SQLPASS

echo "Enter working directory for website (where 'menzshed' dir resides:"
read WORKDIR
if [[ ! -d ${WORKDIR}/menzshed ]]
then
	echo "Can't find ${WORKDIR}/menzshed - exiting"
	exit
fi

export TITLEFILES=" index.php "
export TITLEFILES=" index.php "

export SRCDIR=`pwd`
while [[ "${OPTION}" != [Qq] ]]
do
	# Display screen
	clear	
	echo " Upgrade script for TMZ"
	echo " ======================"
	
	# get statistics
	display_statistics	

	printf " B. Backup file generate\n"
	printf " U. Upgrade Files\n"
	printf " D. Upgrade Database\n"
	printf "\n"
	printf " R. Regenerrate stats\n"
	printf "\n"
	printf " Enter option:"
	read OPTION
	
	case "${OPTION}" in
	[Qq]) ;;
	[Uu]) upgrade_files ;;
	[Bb]) backup_files ;;
	[Dd]) upgrade_database ;;
	[Rr]) regen_statistics ;;
	[Pp]) enter_parameter_files ;;
	*) ;;
	esac
	
done
